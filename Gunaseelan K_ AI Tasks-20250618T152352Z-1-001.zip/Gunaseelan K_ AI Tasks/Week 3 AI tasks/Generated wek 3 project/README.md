# AI-Driven Development - TDD Challenge

This Spring Boot project demonstrates three TDD tasks:

1. **TDD Sprint**: Building a shopping cart feature using Test-Driven Development
2. **Legacy Code Test Coverage**: Adding tests to existing untested code
3. **Edge Case Discovery**: Using AI to find and test edge cases

## Project Structure

```
.
├── src/main/java/com/tddchallenge/
│   ├── task1/                  # Shopping cart implementation using TDD
│   ├── task2/                  # Legacy code with added test coverage
│   └── task3/                  # Edge case testing for critical business logic
├── src/test/java/com/tddchallenge/
│   ├── task1/                  # Tests for shopping cart
│   ├── task2/                  # Tests for legacy code
│   └── task3/                  # Edge case tests
└── documentation/              # Documentation of the process and results
```

## Requirements

- Java 11+
- Maven
- Spring Boot 2.7.5

## Setup

```bash
mvn clean install
```

## Running Tests

```bash
mvn test
```

## Measuring Coverage

```bash
mvn verify
```

JaCoCo coverage reports will be generated in `target/site/jacoco/index.html`