# AI-Driven Development TDD Challenge

## Task 1: TDD Sprint - Shopping Cart

### TASK
Build a complete feature using AI-assisted TDD:
- Choose a feature (shopping cart)
- Use AI to generate comprehensive failing tests
- Implement minimal code to pass tests
- Refactor with AI assistance
- Add integration tests
- Measure coverage and quality

### PROMPT
```
Generate comprehensive failing tests for a shopping cart feature using TDD principles.
The shopping cart should support adding items, updating quantities, removing items,
calculating totals, and applying discounts.
```

### RESPONSE
Generated comprehensive test classes:
- ProductTest: Tests for product creation, validation, equality
- CartItemTest: Tests for cart item creation, quantity updates, subtotal calculation
- ShoppingCartTest: Tests for cart operations, total calculation, discount application
- ShoppingCartIntegrationTest: Tests for complete shopping flows, multiple discount scenarios

### FILE
- src/main/java/com/tddchallenge/task1/model/Product.java
- src/main/java/com/tddchallenge/task1/model/CartItem.java
- src/main/java/com/tddchallenge/task1/service/ShoppingCart.java
- src/test/java/com/tddchallenge/task1/model/ProductTest.java
- src/test/java/com/tddchallenge/task1/model/CartItemTest.java
- src/test/java/com/tddchallenge/task1/service/ShoppingCartTest.java
- src/test/java/com/tddchallenge/task1/integration/ShoppingCartIntegrationTest.java

## Task 2: Legacy Code Test Coverage

### TASK
Add tests to existing untested code:
- Identify a legacy function/class
- Use AI to analyze and generate test plan
- Create wrapper or facade if needed
- Generate comprehensive test suite
- Refactor original code safely

### PROMPT
```
Analyze this legacy PaymentProcessor class and identify areas that need test coverage.
Focus on public methods, edge cases, and potential bugs.
```

### RESPONSE
Created a wrapper class and comprehensive tests:
- Direct tests for PaymentProcessor covering credit card validation, payment processing, currency conversion
- Wrapper pattern implementation to improve testability
- Mockito tests for the wrapper to verify interactions
- Achieved 95% test coverage without modifying the core legacy code

### FILE
- src/main/java/com/tddchallenge/task2/legacy/PaymentProcessor.java
- src/main/java/com/tddchallenge/task2/legacy/PaymentProcessorWrapper.java
- src/test/java/com/tddchallenge/task2/legacy/PaymentProcessorTest.java
- src/test/java/com/tddchallenge/task2/legacy/PaymentProcessorWrapperTest.java

## Task 3: Edge Case Discovery

### TASK
Use AI to find and test edge cases:
- Select critical business logic
- Ask AI to identify potential edge cases
- Generate tests for each edge case
- Implement handling for discovered issues
- Document edge case scenarios

### PROMPT
```
Identify all possible edge cases for an order processing system that handles
order validation, price calculation, shipping costs, discounts, and payment processing.
```

### RESPONSE
Identified 12+ edge cases including:
1. Empty Order: Order with no items
2. Maximum Items Exceeded: Order with more than allowed items
3. Zero Quantity Items: Items with zero quantity
4. Negative Price: Items with negative prices
5. Free Shipping Threshold: Orders just below/above free shipping threshold
6. Payment Failures: Orders with invalid payment details
7. International Shipping: Orders with international addresses
8. Multiple Discounts: Orders eligible for multiple discount types
9. Large Order Quantities: Orders with extremely large quantities
10. Null Customer ID: Orders with missing customer information
11. Empty Promo Code: Orders with empty promotion codes
12. Boundary Conditions: Various boundary conditions in calculations

### FILE
- src/main/java/com/tddchallenge/task3/service/OrderProcessor.java
- src/test/java/com/tddchallenge/task3/service/OrderProcessorEdgeCaseTest.java