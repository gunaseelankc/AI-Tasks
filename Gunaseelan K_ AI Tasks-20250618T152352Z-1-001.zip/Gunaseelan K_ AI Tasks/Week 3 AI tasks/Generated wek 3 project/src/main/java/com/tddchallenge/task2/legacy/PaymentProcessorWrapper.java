package com.tddchallenge.task2.legacy;

/**
 * Wrapper for the legacy PaymentProcessor to make it more testable.
 * This class provides a facade that can be mocked in tests.
 */
public class PaymentProcessorWrapper {
    
    private final PaymentProcessor processor;
    
    public PaymentProcessorWrapper() {
        this.processor = new PaymentProcessor();
    }
    
    // For testing with mock
    public PaymentProcessorWrapper(PaymentProcessor processor) {
        this.processor = processor;
    }
    
    public boolean isValidCreditCard(String cardNumber, String expiryDate, String cvv) {
        return processor.validateCreditCard(cardNumber, expiryDate, cvv);
    }
    
    public PaymentResult processPayment(PaymentRequest request) {
        try {
            double totalAmount = processor.processPayment(
                request.getAmount(),
                request.getCurrency(),
                request.getCardNumber(),
                request.getExpiryDate(),
                request.getCvv()
            );
            
            return new PaymentResult(true, totalAmount, null);
        } catch (Exception e) {
            return new PaymentResult(false, 0, e.getMessage());
        }
    }
    
    public static class PaymentRequest {
        private final double amount;
        private final String currency;
        private final String cardNumber;
        private final String expiryDate;
        private final String cvv;
        
        public PaymentRequest(double amount, String currency, String cardNumber, String expiryDate, String cvv) {
            this.amount = amount;
            this.currency = currency;
            this.cardNumber = cardNumber;
            this.expiryDate = expiryDate;
            this.cvv = cvv;
        }
        
        public double getAmount() { return amount; }
        public String getCurrency() { return currency; }
        public String getCardNumber() { return cardNumber; }
        public String getExpiryDate() { return expiryDate; }
        public String getCvv() { return cvv; }
    }
    
    public static class PaymentResult {
        private final boolean success;
        private final double amount;
        private final String errorMessage;
        
        public PaymentResult(boolean success, double amount, String errorMessage) {
            this.success = success;
            this.amount = amount;
            this.errorMessage = errorMessage;
        }
        
        public boolean isSuccess() { return success; }
        public double getAmount() { return amount; }
        public String getErrorMessage() { return errorMessage; }
    }
}