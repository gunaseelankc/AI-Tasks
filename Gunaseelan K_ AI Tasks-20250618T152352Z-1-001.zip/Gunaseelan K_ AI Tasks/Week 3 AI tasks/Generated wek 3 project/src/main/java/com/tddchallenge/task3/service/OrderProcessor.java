package com.tddchallenge.task3.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Order processing service with critical business logic.
 * This class will be used for edge case discovery and testing.
 */
public class OrderProcessor {

    private static final double TAX_RATE = 0.08;
    private static final double INTERNATIONAL_SHIPPING_RATE = 25.0;
    private static final double DOMESTIC_SHIPPING_RATE = 5.0;
    private static final double FREE_SHIPPING_THRESHOLD = 50.0;
    private static final int MAX_ITEMS_PER_ORDER = 10;
    
    public OrderResult processOrder(Order order) {
        validateOrder(order);
        
        double subtotal = calculateSubtotal(order);
        double tax = calculateTax(subtotal, order.getShippingAddress().getCountry());
        double shippingCost = calculateShippingCost(subtotal, order.getShippingAddress());
        double total = subtotal + tax + shippingCost;
        
        // Apply discount if applicable
        double discount = calculateDiscount(order, subtotal);
        total -= discount;
        
        // Check inventory and process payment
        boolean inventoryAvailable = checkInventory(order.getItems());
        boolean paymentSuccessful = processPayment(order.getPaymentDetails(), total);
        
        if (!inventoryAvailable) {
            return new OrderResult(false, "One or more items are out of stock", 0);
        }
        
        if (!paymentSuccessful) {
            return new OrderResult(false, "Payment processing failed", 0);
        }
        
        // Generate order ID
        String orderId = generateOrderId(order);
        
        return new OrderResult(true, "Order processed successfully", total, orderId);
    }
    
    private void validateOrder(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("Order cannot be null");
        }
        
        if (order.getItems() == null || order.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must contain at least one item");
        }
        
        if (order.getItems().size() > MAX_ITEMS_PER_ORDER) {
            throw new IllegalArgumentException("Order cannot contain more than " + MAX_ITEMS_PER_ORDER + " items");
        }
        
        if (order.getShippingAddress() == null) {
            throw new IllegalArgumentException("Shipping address cannot be null");
        }
        
        if (order.getPaymentDetails() == null) {
            throw new IllegalArgumentException("Payment details cannot be null");
        }
        
        for (OrderItem item : order.getItems()) {
            if (item.getQuantity() <= 0) {
                throw new IllegalArgumentException("Item quantity must be positive");
            }
            
            if (item.getPrice() < 0) {
                throw new IllegalArgumentException("Item price cannot be negative");
            }
        }
    }
    
    private double calculateSubtotal(Order order) {
        return order.getItems().stream()
                .mapToDouble(item -> item.getPrice() * item.getQuantity())
                .sum();
    }
    
    private double calculateTax(double subtotal, String country) {
        // Only apply tax for domestic orders
        return "US".equals(country) ? subtotal * TAX_RATE : 0;
    }
    
    private double calculateShippingCost(double subtotal, Address address) {
        // Free shipping for orders over threshold
        if (subtotal >= FREE_SHIPPING_THRESHOLD) {
            return 0;
        }
        
        // International shipping is more expensive
        return "US".equals(address.getCountry()) ? DOMESTIC_SHIPPING_RATE : INTERNATIONAL_SHIPPING_RATE;
    }
    
    private double calculateDiscount(Order order, double subtotal) {
        // Apply promotional discount if applicable
        if (order.getPromoCode() != null && order.getPromoCode().equals("SAVE10")) {
            return subtotal * 0.1; // 10% discount
        }
        
        // Apply bulk discount for large orders
        if (subtotal > 200) {
            return subtotal * 0.05; // 5% discount
        }
        
        return 0;
    }
    
    private boolean checkInventory(List<OrderItem> items) {
        // Simplified inventory check
        // In a real system, this would check against a database
        return true;
    }
    
    private boolean processPayment(PaymentDetails paymentDetails, double amount) {
        // Simplified payment processing
        // In a real system, this would call a payment gateway
        return !paymentDetails.getCardNumber().equals("1111222233334444"); // Simulate failed payment for this card
    }
    
    private String generateOrderId(Order order) {
        // Generate a unique order ID based on timestamp and customer info
        return "ORD-" + System.currentTimeMillis() + "-" + order.getCustomerId().substring(0, 3);
    }
    
    // Inner classes for the domain model
    
    public static class Order {
        private final String customerId;
        private final List<OrderItem> items;
        private final Address shippingAddress;
        private final PaymentDetails paymentDetails;
        private final String promoCode;
        
        public Order(String customerId, List<OrderItem> items, Address shippingAddress, 
                    PaymentDetails paymentDetails, String promoCode) {
            this.customerId = customerId;
            this.items = items;
            this.shippingAddress = shippingAddress;
            this.paymentDetails = paymentDetails;
            this.promoCode = promoCode;
        }
        
        public String getCustomerId() { return customerId; }
        public List<OrderItem> getItems() { return items; }
        public Address getShippingAddress() { return shippingAddress; }
        public PaymentDetails getPaymentDetails() { return paymentDetails; }
        public String getPromoCode() { return promoCode; }
    }
    
    public static class OrderItem {
        private final String productId;
        private final double price;
        private final int quantity;
        
        public OrderItem(String productId, double price, int quantity) {
            this.productId = productId;
            this.price = price;
            this.quantity = quantity;
        }
        
        public String getProductId() { return productId; }
        public double getPrice() { return price; }
        public int quantity() { return quantity; }
        public int getQuantity() { return quantity; }
    }
    
    public static class Address {
        private final String street;
        private final String city;
        private final String state;
        private final String zipCode;
        private final String country;
        
        public Address(String street, String city, String state, String zipCode, String country) {
            this.street = street;
            this.city = city;
            this.state = state;
            this.zipCode = zipCode;
            this.country = country;
        }
        
        public String getStreet() { return street; }
        public String getCity() { return city; }
        public String getState() { return state; }
        public String getZipCode() { return zipCode; }
        public String getCountry() { return country; }
    }
    
    public static class PaymentDetails {
        private final String cardNumber;
        private final String expiryDate;
        private final String cvv;
        
        public PaymentDetails(String cardNumber, String expiryDate, String cvv) {
            this.cardNumber = cardNumber;
            this.expiryDate = expiryDate;
            this.cvv = cvv;
        }
        
        public String getCardNumber() { return cardNumber; }
        public String getExpiryDate() { return expiryDate; }
        public String getCvv() { return cvv; }
    }
    
    public static class OrderResult {
        private final boolean success;
        private final String message;
        private final double total;
        private final String orderId;
        
        public OrderResult(boolean success, String message, double total) {
            this(success, message, total, null);
        }
        
        public OrderResult(boolean success, String message, double total, String orderId) {
            this.success = success;
            this.message = message;
            this.total = total;
            this.orderId = orderId;
        }
        
        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public double getTotal() { return total; }
        public String getOrderId() { return orderId; }
    }
}