package com.tddchallenge.task2.legacy;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;

/**
 * Legacy payment processor with no tests.
 * This class handles payment validation and processing.
 */
public class PaymentProcessor {
    
    private static final Map<String, Double> CURRENCY_EXCHANGE_RATES = new HashMap<>();
    
    static {
        CURRENCY_EXCHANGE_RATES.put("USD", 1.0);
        CURRENCY_EXCHANGE_RATES.put("EUR", 0.85);
        CURRENCY_EXCHANGE_RATES.put("GBP", 0.75);
        CURRENCY_EXCHANGE_RATES.put("JPY", 110.0);
    }
    
    public boolean validateCreditCard(String cardNumber, String expiryDate, String cvv) {
        // Validate card number (simplified)
        if (cardNumber == null || cardNumber.length() < 13 || cardNumber.length() > 19) {
            return false;
        }
        
        // Check if all digits
        if (!cardNumber.matches("\\d+")) {
            return false;
        }
        
        // Luhn algorithm check
        int sum = 0;
        boolean alternate = false;
        for (int i = cardNumber.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(cardNumber.substring(i, i + 1));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }
        if (sum % 10 != 0) {
            return false;
        }
        
        // Validate expiry date
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yy");
            LocalDate expiry = LocalDate.parse("01/" + expiryDate, formatter).plusMonths(1).minusDays(1);
            if (expiry.isBefore(LocalDate.now())) {
                return false;
            }
        } catch (DateTimeParseException e) {
            return false;
        }
        
        // Validate CVV
        if (cvv == null || !cvv.matches("\\d{3,4}")) {
            return false;
        }
        
        return true;
    }
    
    public double processPayment(double amount, String currency, String cardNumber, String expiryDate, String cvv) {
        if (!validateCreditCard(cardNumber, expiryDate, cvv)) {
            throw new IllegalArgumentException("Invalid credit card details");
        }
        
        if (amount <= 0) {
            throw new IllegalArgumentException("Payment amount must be positive");
        }
        
        // Convert currency if needed
        double amountInUSD = convertToUSD(amount, currency);
        
        // Apply processing fee
        double fee = calculateProcessingFee(amountInUSD);
        double totalAmount = amountInUSD + fee;
        
        // In a real system, we would process the payment here
        System.out.println("Processing payment of " + totalAmount + " USD");
        
        return totalAmount;
    }
    
    private double convertToUSD(double amount, String currency) {
        if (currency == null || !CURRENCY_EXCHANGE_RATES.containsKey(currency)) {
            throw new IllegalArgumentException("Unsupported currency: " + currency);
        }
        
        if (currency.equals("USD")) {
            return amount;
        }
        
        return amount / CURRENCY_EXCHANGE_RATES.get(currency);
    }
    
    private double calculateProcessingFee(double amount) {
        // Fee is 2.5% for amounts under $100, 2% for larger amounts
        if (amount < 100) {
            return amount * 0.025;
        } else {
            return amount * 0.02;
        }
    }
}