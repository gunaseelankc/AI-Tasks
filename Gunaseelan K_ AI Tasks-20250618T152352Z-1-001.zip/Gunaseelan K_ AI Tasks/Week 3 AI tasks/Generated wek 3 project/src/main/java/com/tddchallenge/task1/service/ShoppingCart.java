package com.tddchallenge.task1.service;

import com.tddchallenge.task1.model.CartItem;
import com.tddchallenge.task1.model.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ShoppingCart {
    private final List<CartItem> items;
    private double discountPercent;

    public ShoppingCart() {
        this.items = new ArrayList<>();
        this.discountPercent = 0.0;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public int getItemCount() {
        return items.size();
    }

    public List<CartItem> getItems() {
        return new ArrayList<>(items);
    }

    public void addItem(Product product, int quantity) {
        Optional<CartItem> existingItem = findCartItemByProductId(product.getId());
        
        if (existingItem.isPresent()) {
            CartItem item = existingItem.get();
            item.updateQuantity(item.getQuantity() + quantity);
        } else {
            items.add(new CartItem(product, quantity));
        }
    }

    public void updateItemQuantity(String productId, int quantity) {
        CartItem item = findCartItemByProductId(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found in cart"));
        
        item.updateQuantity(quantity);
    }

    public void removeItem(String productId) {
        CartItem item = findCartItemByProductId(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found in cart"));
        
        items.remove(item);
    }

    public void clear() {
        items.clear();
        discountPercent = 0.0;
    }

    public double getTotal() {
        double subtotal = items.stream()
                .mapToDouble(CartItem::getSubtotal)
                .sum();
        
        return subtotal * (1 - discountPercent / 100.0);
    }

    public void applyDiscount(double discountPercent) {
        if (discountPercent < 0 || discountPercent > 100) {
            throw new IllegalArgumentException("Discount percentage must be between 0 and 100");
        }
        this.discountPercent = discountPercent;
    }

    private Optional<CartItem> findCartItemByProductId(String productId) {
        return items.stream()
                .filter(item -> item.getProduct().getId().equals(productId))
                .findFirst();
    }
}