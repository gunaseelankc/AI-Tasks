package com.tddchallenge.task1.service;

import com.tddchallenge.task1.model.CartItem;
import com.tddchallenge.task1.model.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ShoppingCartTest {

    private ShoppingCart cart;
    private Product product1;
    private Product product2;

    @BeforeEach
    void setUp() {
        cart = new ShoppingCart();
        product1 = new Product("1", "Test Product", 10.0);
        product2 = new Product("2", "Another Product", 20.0);
    }

    @Test
    void testNewCartIsEmpty() {
        assertTrue(cart.isEmpty());
        assertEquals(0, cart.getItemCount());
        assertEquals(0, cart.getItems().size());
        assertEquals(0.0, cart.getTotal(), 0.001);
    }

    @Test
    void testAddItemToCart() {
        cart.addItem(product1, 2);
        
        assertFalse(cart.isEmpty());
        assertEquals(1, cart.getItemCount());
        assertEquals(1, cart.getItems().size());
        assertEquals(20.0, cart.getTotal(), 0.001);
    }

    @Test
    void testAddMultipleItemsToCart() {
        cart.addItem(product1, 2);
        cart.addItem(product2, 1);
        
        assertEquals(2, cart.getItemCount());
        assertEquals(2, cart.getItems().size());
        assertEquals(40.0, cart.getTotal(), 0.001);
    }

    @Test
    void testAddExistingItemIncreasesQuantity() {
        cart.addItem(product1, 2);
        cart.addItem(product1, 3);
        
        assertEquals(1, cart.getItemCount());
        assertEquals(5, cart.getItems().get(0).getQuantity());
        assertEquals(50.0, cart.getTotal(), 0.001);
    }

    @Test
    void testUpdateItemQuantity() {
        cart.addItem(product1, 2);
        cart.updateItemQuantity(product1.getId(), 4);
        
        assertEquals(1, cart.getItemCount());
        assertEquals(4, cart.getItems().get(0).getQuantity());
        assertEquals(40.0, cart.getTotal(), 0.001);
    }

    @Test
    void testUpdateNonExistentItem() {
        cart.addItem(product1, 2);
        
        assertThrows(IllegalArgumentException.class, () -> {
            cart.updateItemQuantity("non-existent", 4);
        });
    }

    @Test
    void testRemoveItem() {
        cart.addItem(product1, 2);
        cart.addItem(product2, 1);
        
        cart.removeItem(product1.getId());
        
        assertEquals(1, cart.getItemCount());
        assertEquals(20.0, cart.getTotal(), 0.001);
    }

    @Test
    void testRemoveNonExistentItem() {
        cart.addItem(product1, 2);
        
        assertThrows(IllegalArgumentException.class, () -> {
            cart.removeItem("non-existent");
        });
    }

    @Test
    void testClearCart() {
        cart.addItem(product1, 2);
        cart.addItem(product2, 1);
        
        cart.clear();
        
        assertTrue(cart.isEmpty());
        assertEquals(0, cart.getItemCount());
        assertEquals(0, cart.getItems().size());
        assertEquals(0.0, cart.getTotal(), 0.001);
    }
    
    @Test
    void testApplyDiscount() {
        cart.addItem(product1, 2); // 20.0
        cart.addItem(product2, 1); // 20.0
        
        cart.applyDiscount(10.0); // 10% discount
        
        assertEquals(36.0, cart.getTotal(), 0.001);
    }
    
    @Test
    void testInvalidDiscount() {
        cart.addItem(product1, 2);
        
        assertThrows(IllegalArgumentException.class, () -> {
            cart.applyDiscount(-10.0);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            cart.applyDiscount(110.0);
        });
    }
}