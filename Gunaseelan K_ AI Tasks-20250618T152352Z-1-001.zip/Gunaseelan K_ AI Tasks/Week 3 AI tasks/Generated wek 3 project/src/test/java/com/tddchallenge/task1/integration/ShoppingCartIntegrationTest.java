package com.tddchallenge.task1.integration;

import com.tddchallenge.task1.model.Product;
import com.tddchallenge.task1.service.ShoppingCart;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ShoppingCartIntegrationTest {

    private ShoppingCart cart;
    private Product laptop;
    private Product mouse;
    private Product keyboard;

    @BeforeEach
    void setUp() {
        cart = new ShoppingCart();
        laptop = new Product("P001", "Laptop", 1200.0);
        mouse = new Product("P002", "Mouse", 25.0);
        keyboard = new Product("P003", "Keyboard", 50.0);
    }

    @Test
    void testCompleteShoppingFlow() {
        // Start with empty cart
        assertTrue(cart.isEmpty());
        
        // Add items to cart
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 2);
        
        // Verify cart state
        assertFalse(cart.isEmpty());
        assertEquals(2, cart.getItemCount());
        assertEquals(1250.0, cart.getTotal(), 0.001);
        
        // Update quantity
        cart.updateItemQuantity(mouse.getId(), 3);
        assertEquals(1275.0, cart.getTotal(), 0.001);
        
        // Add another item
        cart.addItem(keyboard, 1);
        assertEquals(3, cart.getItemCount());
        assertEquals(1325.0, cart.getTotal(), 0.001);
        
        // Apply discount
        cart.applyDiscount(10.0);
        assertEquals(1192.5, cart.getTotal(), 0.001);
        
        // Remove an item
        cart.removeItem(keyboard.getId());
        assertEquals(2, cart.getItemCount());
        assertEquals(1147.5, cart.getTotal(), 0.001);
        
        // Clear cart
        cart.clear();
        assertTrue(cart.isEmpty());
        assertEquals(0.0, cart.getTotal(), 0.001);
    }
    
    @Test
    void testMultipleDiscountScenarios() {
        // Add items
        cart.addItem(laptop, 1);
        cart.addItem(mouse, 1);
        cart.addItem(keyboard, 1);
        
        // Total without discount
        assertEquals(1275.0, cart.getTotal(), 0.001);
        
        // Apply 5% discount
        cart.applyDiscount(5.0);
        assertEquals(1211.25, cart.getTotal(), 0.001);
        
        // Change to 15% discount
        cart.applyDiscount(15.0);
        assertEquals(1083.75, cart.getTotal(), 0.001);
        
        // Remove discount
        cart.applyDiscount(0.0);
        assertEquals(1275.0, cart.getTotal(), 0.001);
    }
    
    @Test
    void testAddingSameProductMultipleTimes() {
        // Add same product multiple times
        cart.addItem(mouse, 1);
        cart.addItem(mouse, 2);
        cart.addItem(mouse, 3);
        
        // Should combine quantities
        assertEquals(1, cart.getItemCount());
        assertEquals(6, cart.getItems().get(0).getQuantity());
        assertEquals(150.0, cart.getTotal(), 0.001);
    }
}