package com.tddchallenge.task1.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void testProductCreation() {
        Product product = new Product("1", "Test Product", 10.0);
        
        assertEquals("1", product.getId());
        assertEquals("Test Product", product.getName());
        assertEquals(10.0, product.getPrice(), 0.001);
    }
    
    @Test
    void testProductEquality() {
        Product product1 = new Product("1", "Test Product", 10.0);
        Product product2 = new Product("1", "Test Product", 10.0);
        Product product3 = new Product("2", "Another Product", 20.0);
        
        assertEquals(product1, product2);
        assertNotEquals(product1, product3);
    }
    
    @Test
    void testProductHashCode() {
        Product product1 = new Product("1", "Test Product", 10.0);
        Product product2 = new Product("1", "Test Product", 10.0);
        
        assertEquals(product1.hashCode(), product2.hashCode());
    }
    
    @Test
    void testInvalidProductPrice() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Product("1", "Test Product", -10.0);
        });
    }
    
    @Test
    void testInvalidProductId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Product(null, "Test Product", 10.0);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Product("", "Test Product", 10.0);
        });
    }
    
    @Test
    void testInvalidProductName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Product("1", null, 10.0);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Product("1", "", 10.0);
        });
    }
}