package com.tddchallenge.task2.legacy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class PaymentProcessorTest {

    private PaymentProcessor paymentProcessor;

    @BeforeEach
    void setUp() {
        paymentProcessor = new PaymentProcessor();
    }

    @Test
    void testValidCreditCard() {
        // Valid Visa test card
        assertTrue(paymentProcessor.validateCreditCard("4111111111111111", "12/25", "123"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "123", "12345678901234567890"})
    void testInvalidCardNumberLength(String cardNumber) {
        assertFalse(paymentProcessor.validateCreditCard(cardNumber, "12/25", "123"));
    }

    @Test
    void testNonNumericCardNumber() {
        assertFalse(paymentProcessor.validateCreditCard("4111111111111abc", "12/25", "123"));
    }

    @Test
    void testFailedLuhnCheck() {
        assertFalse(paymentProcessor.validateCreditCard("4111111111111112", "12/25", "123"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"00/20", "01/20", "12/19"})
    void testExpiredCard(String expiryDate) {
        assertFalse(paymentProcessor.validateCreditCard("4111111111111111", expiryDate, "123"));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "1", "12", "12345", "abc"})
    void testInvalidCVV(String cvv) {
        assertFalse(paymentProcessor.validateCreditCard("4111111111111111", "12/25", cvv));
    }

    @Test
    void testSuccessfulPaymentProcessing() {
        double result = paymentProcessor.processPayment(100.0, "USD", "4111111111111111", "12/25", "123");
        assertEquals(102.0, result, 0.001); // $100 + 2% fee
    }

    @Test
    void testSmallPaymentHigherFee() {
        double result = paymentProcessor.processPayment(50.0, "USD", "4111111111111111", "12/25", "123");
        assertEquals(51.25, result, 0.001); // $50 + 2.5% fee
    }

    @ParameterizedTest
    @CsvSource({
        "100.0, EUR, 117.65",
        "100.0, GBP, 133.33",
        "100.0, JPY, 0.91"
    })
    void testCurrencyConversion(double amount, String currency, double expected) {
        double result = paymentProcessor.processPayment(amount, currency, "4111111111111111", "12/25", "123");
        assertEquals(expected, result, 0.01);
    }

    @Test
    void testInvalidCurrency() {
        assertThrows(IllegalArgumentException.class, () -> {
            paymentProcessor.processPayment(100.0, "XYZ", "4111111111111111", "12/25", "123");
        });
    }

    @Test
    void testNegativeAmount() {
        assertThrows(IllegalArgumentException.class, () -> {
            paymentProcessor.processPayment(-100.0, "USD", "4111111111111111", "12/25", "123");
        });
    }

    @Test
    void testInvalidCardForPayment() {
        assertThrows(IllegalArgumentException.class, () -> {
            paymentProcessor.processPayment(100.0, "USD", "1234567890123456", "12/25", "123");
        });
    }
}