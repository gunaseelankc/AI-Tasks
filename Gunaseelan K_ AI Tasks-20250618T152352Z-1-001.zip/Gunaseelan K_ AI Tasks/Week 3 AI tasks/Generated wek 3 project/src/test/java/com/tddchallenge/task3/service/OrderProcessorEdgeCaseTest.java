package com.tddchallenge.task3.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Edge case tests for OrderProcessor
 */
class OrderProcessorEdgeCaseTest {

    private OrderProcessor orderProcessor;
    private OrderProcessor.PaymentDetails validPayment;
    private OrderProcessor.Address domesticAddress;
    private OrderProcessor.Address internationalAddress;

    @BeforeEach
    void setUp() {
        orderProcessor = new OrderProcessor();
        validPayment = new OrderProcessor.PaymentDetails("4111111111111111", "12/25", "123");
        domesticAddress = new OrderProcessor.Address("123 Main St", "Anytown", "CA", "12345", "US");
        internationalAddress = new OrderProcessor.Address("456 High St", "London", "", "SW1A 1AA", "UK");
    }

    // Edge Case 1: Empty order
    @Test
    void testEmptyOrder() {
        List<OrderProcessor.OrderItem> emptyItems = Collections.emptyList();
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", emptyItems, domesticAddress, validPayment, null);
        
        assertThrows(IllegalArgumentException.class, () -> {
            orderProcessor.processOrder(order);
        });
    }

    // Edge Case 2: Maximum items per order
    @Test
    void testMaxItemsExceeded() {
        List<OrderProcessor.OrderItem> tooManyItems = new ArrayList<>();
        for (int i = 0; i < 11; i++) {
            tooManyItems.add(new OrderProcessor.OrderItem("PROD" + i, 10.0, 1));
        }
        
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", tooManyItems, domesticAddress, validPayment, null);
        
        assertThrows(IllegalArgumentException.class, () -> {
            orderProcessor.processOrder(order);
        });
    }

    // Edge Case 3: Zero quantity items
    @Test
    void testZeroQuantityItem() {
        OrderProcessor.OrderItem zeroQuantityItem = new OrderProcessor.OrderItem("PROD1", 10.0, 0);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(zeroQuantityItem), domesticAddress, validPayment, null);
        
        assertThrows(IllegalArgumentException.class, () -> {
            orderProcessor.processOrder(order);
        });
    }

    // Edge Case 4: Negative price
    @Test
    void testNegativePrice() {
        OrderProcessor.OrderItem negativePrice = new OrderProcessor.OrderItem("PROD1", -10.0, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(negativePrice), domesticAddress, validPayment, null);
        
        assertThrows(IllegalArgumentException.class, () -> {
            orderProcessor.processOrder(order);
        });
    }

    // Edge Case 5: Order just below free shipping threshold
    @Test
    void testJustBelowFreeShippingThreshold() {
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 49.99, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(item), domesticAddress, validPayment, null);
        
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertTrue(result.isSuccess());
        assertEquals(49.99 + (49.99 * 0.08) + 5.0, result.getTotal(), 0.01); // Subtotal + tax + shipping
    }

    // Edge Case 6: Order just above free shipping threshold
    @Test
    void testJustAboveFreeShippingThreshold() {
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 50.01, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(item), domesticAddress, validPayment, null);
        
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertTrue(result.isSuccess());
        assertEquals(50.01 + (50.01 * 0.08), result.getTotal(), 0.01); // Subtotal + tax (no shipping)
    }

    // Edge Case 7: Failed payment
    @Test
    void testFailedPayment() {
        OrderProcessor.PaymentDetails failingPayment = new OrderProcessor.PaymentDetails("1111222233334444", "12/25", "123");
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 10.0, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(item), domesticAddress, failingPayment, null);
        
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertFalse(result.isSuccess());
        assertEquals("Payment processing failed", result.getMessage());
    }

    // Edge Case 8: International shipping with free shipping threshold
    @Test
    void testInternationalOrderWithFreeShipping() {
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 100.0, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(item), internationalAddress, validPayment, null);
        
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertTrue(result.isSuccess());
        assertEquals(100.0, result.getTotal(), 0.01); // No tax for international, free shipping
    }

    // Edge Case 9: Multiple discounts (only highest should apply)
    @Test
    void testMultipleDiscounts() {
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 250.0, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(item), domesticAddress, validPayment, "SAVE10");
        
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertTrue(result.isSuccess());
        // 10% promo discount should apply (higher than 5% bulk discount)
        assertEquals(250.0 + (250.0 * 0.08) - (250.0 * 0.1), result.getTotal(), 0.01);
    }

    // Edge Case 10: Very large order quantity
    @Test
    void testVeryLargeOrderQuantity() {
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 1.0, 1000);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(item), domesticAddress, validPayment, null);
        
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertTrue(result.isSuccess());
        // 1000 items at $1 each = $1000, with 5% bulk discount and 8% tax
        assertEquals(1000.0 + (1000.0 * 0.08) - (1000.0 * 0.05), result.getTotal(), 0.01);
    }

    // Edge Case 11: Null customer ID
    @Test
    void testNullCustomerId() {
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 10.0, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                null, Collections.singletonList(item), domesticAddress, validPayment, null);
        
        // This should still work, but might generate a different order ID
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertTrue(result.isSuccess());
        assertNotNull(result.getOrderId());
    }

    // Edge Case 12: Empty promo code
    @Test
    void testEmptyPromoCode() {
        OrderProcessor.OrderItem item = new OrderProcessor.OrderItem("PROD1", 10.0, 1);
        OrderProcessor.Order order = new OrderProcessor.Order(
                "CUST123", Collections.singletonList(item), domesticAddress, validPayment, "");
        
        OrderProcessor.OrderResult result = orderProcessor.processOrder(order);
        
        assertTrue(result.isSuccess());
        // No discount should be applied
        assertEquals(10.0 + (10.0 * 0.08) + 5.0, result.getTotal(), 0.01);
    }
}