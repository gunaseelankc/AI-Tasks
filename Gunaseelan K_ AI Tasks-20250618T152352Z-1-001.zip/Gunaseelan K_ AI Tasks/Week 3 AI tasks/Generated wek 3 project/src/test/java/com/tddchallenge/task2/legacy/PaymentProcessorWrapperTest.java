package com.tddchallenge.task2.legacy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PaymentProcessorWrapperTest {

    private PaymentProcessor mockProcessor;
    private PaymentProcessorWrapper wrapper;

    @BeforeEach
    void setUp() {
        mockProcessor = mock(PaymentProcessor.class);
        wrapper = new PaymentProcessorWrapper(mockProcessor);
    }

    @Test
    void testSuccessfulPaymentProcessing() {
        // Arrange
        PaymentProcessorWrapper.PaymentRequest request = 
            new PaymentProcessorWrapper.PaymentRequest(100.0, "USD", "4111111111111111", "12/25", "123");
        
        when(mockProcessor.validateCreditCard("4111111111111111", "12/25", "123")).thenReturn(true);
        when(mockProcessor.processPayment(100.0, "USD", "4111111111111111", "12/25", "123")).thenReturn(102.0);
        
        // Act
        PaymentProcessorWrapper.PaymentResult result = wrapper.processPayment(request);
        
        // Assert
        assertTrue(result.isSuccess());
        assertEquals(102.0, result.getAmount(), 0.001);
        assertNull(result.getErrorMessage());
        
        verify(mockProcessor).processPayment(100.0, "USD", "4111111111111111", "12/25", "123");
    }

    @Test
    void testFailedPaymentProcessing() {
        // Arrange
        PaymentProcessorWrapper.PaymentRequest request = 
            new PaymentProcessorWrapper.PaymentRequest(100.0, "USD", "invalid", "12/25", "123");
        
        when(mockProcessor.validateCreditCard("invalid", "12/25", "123")).thenReturn(false);
        when(mockProcessor.processPayment(100.0, "USD", "invalid", "12/25", "123"))
            .thenThrow(new IllegalArgumentException("Invalid credit card details"));
        
        // Act
        PaymentProcessorWrapper.PaymentResult result = wrapper.processPayment(request);
        
        // Assert
        assertFalse(result.isSuccess());
        assertEquals(0.0, result.getAmount(), 0.001);
        assertEquals("Invalid credit card details", result.getErrorMessage());
    }

    @Test
    void testCreditCardValidation() {
        // Arrange
        when(mockProcessor.validateCreditCard("4111111111111111", "12/25", "123")).thenReturn(true);
        when(mockProcessor.validateCreditCard("invalid", "12/25", "123")).thenReturn(false);
        
        // Act & Assert
        assertTrue(wrapper.isValidCreditCard("4111111111111111", "12/25", "123"));
        assertFalse(wrapper.isValidCreditCard("invalid", "12/25", "123"));
        
        verify(mockProcessor, times(1)).validateCreditCard("4111111111111111", "12/25", "123");
        verify(mockProcessor, times(1)).validateCreditCard("invalid", "12/25", "123");
    }
}