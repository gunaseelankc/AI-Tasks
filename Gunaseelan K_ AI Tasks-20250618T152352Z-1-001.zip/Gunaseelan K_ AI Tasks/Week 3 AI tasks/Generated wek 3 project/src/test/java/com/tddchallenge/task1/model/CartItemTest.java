package com.tddchallenge.task1.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CartItemTest {

    @Test
    void testCartItemCreation() {
        Product product = new Product("1", "Test Product", 10.0);
        CartItem cartItem = new CartItem(product, 2);
        
        assertEquals(product, cartItem.getProduct());
        assertEquals(2, cartItem.getQuantity());
        assertEquals(20.0, cartItem.getSubtotal(), 0.001);
    }
    
    @Test
    void testCartItemUpdateQuantity() {
        Product product = new Product("1", "Test Product", 10.0);
        CartItem cartItem = new CartItem(product, 2);
        
        cartItem.updateQuantity(3);
        assertEquals(3, cartItem.getQuantity());
        assertEquals(30.0, cartItem.getSubtotal(), 0.001);
    }
    
    @Test
    void testCartItemInvalidQuantity() {
        Product product = new Product("1", "Test Product", 10.0);
        
        assertThrows(IllegalArgumentException.class, () -> {
            new CartItem(product, 0);
        });
        
        assertThrows(IllegalArgumentException.class, () -> {
            new CartItem(product, -1);
        });
        
        CartItem cartItem = new CartItem(product, 2);
        assertThrows(IllegalArgumentException.class, () -> {
            cartItem.updateQuantity(0);
        });
    }
    
    @Test
    void testCartItemNullProduct() {
        assertThrows(IllegalArgumentException.class, () -> {
            new CartItem(null, 1);
        });
    }
    
    @Test
    void testCartItemEquality() {
        Product product1 = new Product("1", "Test Product", 10.0);
        Product product2 = new Product("2", "Another Product", 20.0);
        
        CartItem cartItem1 = new CartItem(product1, 2);
        CartItem cartItem2 = new CartItem(product1, 2);
        CartItem cartItem3 = new CartItem(product2, 2);
        
        assertEquals(cartItem1, cartItem2);
        assertNotEquals(cartItem1, cartItem3);
    }
}