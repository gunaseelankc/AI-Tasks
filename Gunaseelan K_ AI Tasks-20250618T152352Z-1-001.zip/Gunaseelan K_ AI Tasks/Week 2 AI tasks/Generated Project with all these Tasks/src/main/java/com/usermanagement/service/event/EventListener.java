package com.usermanagement.service.event;

/**
 * Interface for the Observer pattern.
 * Event listeners implement this interface to receive notifications.
 */
public interface EventListener {
    
    /**
     * Called when an event occurs.
     * 
     * @param event The event that occurred
     */
    void onEvent(Event event);
    
    /**
     * Returns the type of events this listener is interested in.
     * 
     * @return The event type this listener handles
     */
    EventType getEventType();
}