package com.usermanagement.service.payment;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Credit Card payment strategy implementation.
 */
@Component
@Slf4j
public class CreditCardPayment implements PaymentStrategy {

    @Override
    public PaymentResult processPayment(BigDecimal amount, String currency) {
        log.info("Processing credit card payment of {} {}", amount, currency);
        
        // Simulate credit card processing
        try {
            // In a real implementation, this would call a payment gateway API
            Thread.sleep(500); // Simulate network delay
            
            // Generate a transaction ID
            String transactionId = "CC-" + UUID.randomUUID().toString();
            
            log.info("Credit card payment successful: {}", transactionId);
            return PaymentResult.success(transactionId, amount, currency, getMethodName());
        } catch (Exception e) {
            log.error("Credit card payment failed", e);
            return PaymentResult.failed("Credit card processing error: " + e.getMessage(), 
                    amount, currency, getMethodName());
        }
    }

    @Override
    public boolean isAvailable(BigDecimal amount, String currency) {
        // Credit cards typically have upper limits
        boolean isAvailable = amount.compareTo(BigDecimal.valueOf(50000)) <= 0;
        log.debug("Credit card payment availability check: {}", isAvailable);
        return isAvailable;
    }

    @Override
    public String getMethodName() {
        return "Credit Card";
    }
}