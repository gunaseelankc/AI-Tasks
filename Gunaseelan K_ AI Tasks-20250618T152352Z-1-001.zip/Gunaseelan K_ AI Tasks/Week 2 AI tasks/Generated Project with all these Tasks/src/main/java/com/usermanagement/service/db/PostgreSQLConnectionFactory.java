package com.usermanagement.service.db;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Factory for creating PostgreSQL database connections.
 * This is a concrete implementation of the Factory Pattern.
 */
@Component
@Slf4j
public class PostgreSQLConnectionFactory implements DatabaseConnectionFactory {
    
    @Value("${spring.datasource.url:jdbc:postgresql://localhost:5432/userdb}")
    private String url;
    
    @Value("${spring.datasource.username:postgres}")
    private String username;
    
    @Value("${spring.datasource.password:postgres}")
    private String password;
    
    @Override
    public DatabaseConnection createConnection() throws DatabaseException {
        try {
            log.info("Creating PostgreSQL connection to {}", url);
            Connection connection = DriverManager.getConnection(url, username, password);
            return new PostgreSQLConnection(connection);
        } catch (SQLException e) {
            log.error("Failed to create PostgreSQL connection", e);
            throw new DatabaseException("Failed to create PostgreSQL connection", e);
        }
    }
    
    @Override
    public DatabaseType getDatabaseType() {
        return DatabaseType.POSTGRESQL;
    }
    
    /**
     * PostgreSQL specific implementation of DatabaseConnection.
     */
    private static class PostgreSQLConnection implements DatabaseConnection {
        
        private final Connection connection;
        
        public PostgreSQLConnection(Connection connection) {
            this.connection = connection;
        }
        
        @Override
        public Connection getConnection() {
            return connection;
        }
        
        @Override
        public boolean isValid(int timeout) {
            try {
                return connection.isValid(timeout);
            } catch (SQLException e) {
                log.error("Error checking connection validity", e);
                return false;
            }
        }
        
        @Override
        public void close() throws DatabaseException {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                }
            } catch (SQLException e) {
                throw new DatabaseException("Failed to close PostgreSQL connection", e);
            }
        }
        
        @Override
        public DatabaseType getDatabaseType() {
            return DatabaseType.POSTGRESQL;
        }
    }
}