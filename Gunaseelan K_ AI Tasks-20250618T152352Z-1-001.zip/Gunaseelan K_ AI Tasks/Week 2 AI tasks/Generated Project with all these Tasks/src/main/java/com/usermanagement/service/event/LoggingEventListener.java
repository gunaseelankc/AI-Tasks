package com.usermanagement.service.event;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Event listener that logs all events.
 * This is a concrete implementation of the Observer pattern.
 */
@Component
@Slf4j
public class LoggingEventListener implements EventListener {
    
    @Override
    public void onEvent(Event event) {
        log.info("Event received: [{}] Type: {}, Source: {}, Data: {}", 
                event.getId(), event.getType(), event.getSource(), event.getData());
    }
    
    @Override
    public EventType getEventType() {
        // This listener is interested in all events
        return null;
    }
}