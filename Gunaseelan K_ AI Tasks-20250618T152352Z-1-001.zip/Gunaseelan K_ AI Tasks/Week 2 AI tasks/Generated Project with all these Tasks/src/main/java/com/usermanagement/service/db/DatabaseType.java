package com.usermanagement.service.db;

/**
 * Enum representing different types of databases.
 */
public enum DatabaseType {
    POSTGRESQL,
    MYSQL,
    H2,
    ORACLE,
    SQLSERVER
}