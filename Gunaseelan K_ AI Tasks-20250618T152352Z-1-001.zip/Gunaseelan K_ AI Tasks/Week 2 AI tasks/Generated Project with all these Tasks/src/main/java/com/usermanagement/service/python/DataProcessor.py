#!/usr/bin/env python3
"""
Data processing module for user data analysis.
This is a Python module that will be converted to Java.
"""

import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Union

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DataProcessor:
    """Class for processing user data."""
    
    def __init__(self, data_dir: str = "./data"):
        """
        Initialize the data processor.
        
        Args:
            data_dir: Directory containing data files
        """
        self.data_dir = data_dir
        self.users = []
        self.stats = {}
    
    def load_data(self, filename: str) -> bool:
        """
        Load user data from a JSON file.
        
        Args:
            filename: Name of the file to load
            
        Returns:
            bool: True if data was loaded successfully, False otherwise
        """
        try:
            file_path = os.path.join(self.data_dir, filename)
            logger.info(f"Loading data from {file_path}")
            
            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                return False
            
            with open(file_path, 'r') as file:
                self.users = json.load(file)
            
            logger.info(f"Loaded {len(self.users)} users")
            return True
        except Exception as e:
            logger.error(f"Error loading data: {str(e)}")
            return False
    
    def filter_users_by_date(self, start_date: str, end_date: str) -> List[Dict]:
        """
        Filter users by creation date range.
        
        Args:
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            List of users within the date range
        """
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
            
            filtered_users = []
            for user in self.users:
                if "created_at" in user:
                    created_at = datetime.strptime(user["created_at"], "%Y-%m-%d %H:%M:%S")
                    if start <= created_at <= end:
                        filtered_users.append(user)
            
            logger.info(f"Filtered {len(filtered_users)} users between {start_date} and {end_date}")
            return filtered_users
        except ValueError as e:
            logger.error(f"Date format error: {str(e)}")
            return []
        except Exception as e:
            logger.error(f"Error filtering users: {str(e)}")
            return []
    
    def calculate_statistics(self, users: Optional[List[Dict]] = None) -> Dict:
        """
        Calculate statistics on user data.
        
        Args:
            users: List of users to analyze, uses self.users if None
            
        Returns:
            Dictionary containing statistics
        """
        if users is None:
            users = self.users
        
        if not users:
            logger.warning("No users to calculate statistics")
            return {}
        
        try:
            # Count users by domain
            domains = {}
            for user in users:
                if "email" in user:
                    domain = user["email"].split("@")[-1]
                    domains[domain] = domains.get(domain, 0) + 1
            
            # Get most common domain
            most_common_domain = max(domains.items(), key=lambda x: x[1]) if domains else ("", 0)
            
            # Calculate average username length
            username_lengths = [len(user.get("username", "")) for user in users if "username" in user]
            avg_username_length = sum(username_lengths) / len(username_lengths) if username_lengths else 0
            
            stats = {
                "total_users": len(users),
                "domains": domains,
                "most_common_domain": most_common_domain[0],
                "most_common_domain_count": most_common_domain[1],
                "avg_username_length": avg_username_length
            }
            
            self.stats = stats
            logger.info(f"Calculated statistics for {len(users)} users")
            return stats
        except Exception as e:
            logger.error(f"Error calculating statistics: {str(e)}")
            return {}
    
    def export_results(self, output_file: str, data: Union[List, Dict]) -> bool:
        """
        Export results to a JSON file.
        
        Args:
            output_file: Name of the output file
            data: Data to export
            
        Returns:
            bool: True if data was exported successfully, False otherwise
        """
        try:
            output_path = os.path.join(self.data_dir, output_file)
            logger.info(f"Exporting results to {output_path}")
            
            with open(output_path, 'w') as file:
                json.dump(data, file, indent=2)
            
            logger.info(f"Results exported successfully")
            return True
        except Exception as e:
            logger.error(f"Error exporting results: {str(e)}")
            return False
    
    def process_data(self, input_file: str, output_file: str, start_date: Optional[str] = None, end_date: Optional[str] = None) -> bool:
        """
        Process data from input file and export results.
        
        Args:
            input_file: Input JSON file
            output_file: Output JSON file
            start_date: Optional start date filter
            end_date: Optional end date filter
            
        Returns:
            bool: True if processing was successful, False otherwise
        """
        if not self.load_data(input_file):
            return False
        
        users_to_process = self.users
        
        # Apply date filter if provided
        if start_date and end_date:
            users_to_process = self.filter_users_by_date(start_date, end_date)
            if not users_to_process:
                logger.warning("No users match the date filter")
                return False
        
        stats = self.calculate_statistics(users_to_process)
        if not stats:
            return False
        
        result = {
            "processed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "input_file": input_file,
            "total_records": len(self.users),
            "processed_records": len(users_to_process),
            "statistics": stats
        }
        
        return self.export_results(output_file, result)


# Example usage
if __name__ == "__main__":
    processor = DataProcessor()
    success = processor.process_data("users.json", "stats.json", "2023-01-01", "2023-12-31")
    print(f"Processing {'successful' if success else 'failed'}")