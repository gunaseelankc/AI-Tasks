package com.usermanagement.service.event;

/**
 * Enum representing different types of events in the system.
 */
public enum EventType {
    USER_CREATED,
    USER_UPDATED,
    USER_DELETED,
    USER_LOGIN,
    PAYMENT_PROCESSED,
    PAYMENT_FAILED,
    SYSTEM_ERROR
}