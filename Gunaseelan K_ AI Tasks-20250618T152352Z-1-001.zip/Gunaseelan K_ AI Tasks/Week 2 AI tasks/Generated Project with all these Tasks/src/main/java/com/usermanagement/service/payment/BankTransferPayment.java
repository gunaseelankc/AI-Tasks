package com.usermanagement.service.payment;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Bank Transfer payment strategy implementation.
 */
@Component
@Slf4j
public class BankTransferPayment implements PaymentStrategy {

    @Override
    public PaymentResult processPayment(BigDecimal amount, String currency) {
        log.info("Processing bank transfer payment of {} {}", amount, currency);
        
        // Simulate bank transfer processing
        try {
            // In a real implementation, this would initiate a bank transfer
            Thread.sleep(1000); // Bank transfers typically take longer
            
            // Generate a transaction ID
            String transactionId = "BT-" + UUID.randomUUID().toString();
            
            log.info("Bank transfer initiated successfully: {}", transactionId);
            return PaymentResult.success(transactionId, amount, currency, getMethodName());
        } catch (Exception e) {
            log.error("Bank transfer failed", e);
            return PaymentResult.failed("Bank transfer processing error: " + e.getMessage(), 
                    amount, currency, getMethodName());
        }
    }

    @Override
    public boolean isAvailable(BigDecimal amount, String currency) {
        // Bank transfers are typically available for larger amounts
        boolean isAvailable = true; // No upper limit for bank transfers
        log.debug("Bank transfer availability check: {}", isAvailable);
        return isAvailable;
    }

    @Override
    public String getMethodName() {
        return "Bank Transfer";
    }
}