package com.usermanagement.service.payment;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Payment processor service that uses the Strategy pattern to process payments
 * through different payment methods.
 */
@Service
@Slf4j
public class PaymentProcessor {

    private final List<PaymentStrategy> paymentStrategies;

    @Autowired
    public PaymentProcessor(List<PaymentStrategy> paymentStrategies) {
        this.paymentStrategies = paymentStrategies;
    }

    /**
     * Process a payment using the specified payment method.
     *
     * @param amount The payment amount
     * @param currency The currency code
     * @param paymentMethod The name of the payment method to use
     * @return PaymentResult containing the result of the payment processing
     * @throws IllegalArgumentException if the payment method is not available
     */
    public PaymentResult processPayment(BigDecimal amount, String currency, String paymentMethod) {
        log.info("Processing payment of {} {} using {}", amount, currency, paymentMethod);
        
        Optional<PaymentStrategy> strategy = paymentStrategies.stream()
                .filter(s -> s.getMethodName().equalsIgnoreCase(paymentMethod))
                .findFirst();
        
        if (strategy.isEmpty()) {
            log.error("Payment method not found: {}", paymentMethod);
            throw new IllegalArgumentException("Payment method not found: " + paymentMethod);
        }
        
        PaymentStrategy paymentStrategy = strategy.get();
        
        if (!paymentStrategy.isAvailable(amount, currency)) {
            log.error("Payment method {} is not available for {} {}", paymentMethod, amount, currency);
            throw new IllegalArgumentException(
                    String.format("Payment method %s is not available for %s %s", paymentMethod, amount, currency));
        }
        
        return paymentStrategy.processPayment(amount, currency);
    }

    /**
     * Get all available payment methods for the given amount and currency.
     *
     * @param amount The payment amount
     * @param currency The currency code
     * @return List of available payment method names
     */
    public List<String> getAvailablePaymentMethods(BigDecimal amount, String currency) {
        log.debug("Getting available payment methods for {} {}", amount, currency);
        
        return paymentStrategies.stream()
                .filter(strategy -> strategy.isAvailable(amount, currency))
                .map(PaymentStrategy::getMethodName)
                .toList();
    }
}