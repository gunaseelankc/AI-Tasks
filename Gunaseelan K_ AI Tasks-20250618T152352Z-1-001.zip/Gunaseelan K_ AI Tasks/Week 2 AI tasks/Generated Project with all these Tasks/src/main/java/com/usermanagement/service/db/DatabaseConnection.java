package com.usermanagement.service.db;

import java.sql.Connection;

/**
 * Interface representing a database connection.
 * This is part of the Factory Pattern implementation.
 */
public interface DatabaseConnection {
    
    /**
     * Get the underlying JDBC connection.
     * 
     * @return The JDBC connection
     */
    Connection getConnection();
    
    /**
     * Check if the connection is valid.
     * 
     * @param timeout Timeout in seconds
     * @return true if the connection is valid, false otherwise
     */
    boolean isValid(int timeout);
    
    /**
     * Close the connection.
     * 
     * @throws DatabaseException if closing the connection fails
     */
    void close() throws DatabaseException;
    
    /**
     * Get the database type this connection is for.
     * 
     * @return The database type
     */
    DatabaseType getDatabaseType();
}