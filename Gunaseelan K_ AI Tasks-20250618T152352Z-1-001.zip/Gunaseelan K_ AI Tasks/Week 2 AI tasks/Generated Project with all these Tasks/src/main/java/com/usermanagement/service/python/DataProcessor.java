package com.usermanagement.service.python;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Java implementation of the Python DataProcessor class.
 * This class processes user data for analysis.
 */
public class DataProcessor {
    private static final Logger logger = LoggerFactory.getLogger(DataProcessor.class);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    private final String dataDir;
    private List<Map<String, Object>> users;
    private Map<String, Object> stats;
    private final ObjectMapper objectMapper;
    
    /**
     * Initialize the data processor.
     * 
     * @param dataDir Directory containing data files
     */
    public DataProcessor(String dataDir) {
        this.dataDir = dataDir;
        this.users = new ArrayList<>();
        this.stats = new HashMap<>();
        this.objectMapper = new ObjectMapper();
    }
    
    /**
     * Default constructor using "./data" as the data directory.
     */
    public DataProcessor() {
        this("./data");
    }
    
    /**
     * Load user data from a JSON file.
     * 
     * @param filename Name of the file to load
     * @return true if data was loaded successfully, false otherwise
     */
    public boolean loadData(String filename) {
        try {
            Path filePath = Paths.get(dataDir, filename);
            logger.info("Loading data from {}", filePath);
            
            if (!Files.exists(filePath)) {
                logger.error("File not found: {}", filePath);
                return false;
            }
            
            users = objectMapper.readValue(filePath.toFile(), new TypeReference<List<Map<String, Object>>>() {});
            
            logger.info("Loaded {} users", users.size());
            return true;
        } catch (IOException e) {
            logger.error("Error loading data: {}", e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Filter users by creation date range.
     * 
     * @param startDate Start date in YYYY-MM-DD format
     * @param endDate End date in YYYY-MM-DD format
     * @return List of users within the date range
     */
    public List<Map<String, Object>> filterUsersByDate(String startDate, String endDate) {
        try {
            LocalDate start = LocalDate.parse(startDate, DATE_FORMATTER);
            LocalDate end = LocalDate.parse(endDate, DATE_FORMATTER);
            
            List<Map<String, Object>> filteredUsers = new ArrayList<>();
            
            for (Map<String, Object> user : users) {
                if (user.containsKey("created_at")) {
                    LocalDateTime createdAt = LocalDateTime.parse(user.get("created_at").toString(), DATETIME_FORMATTER);
                    LocalDate createdDate = createdAt.toLocalDate();
                    
                    if (!createdDate.isBefore(start) && !createdDate.isAfter(end)) {
                        filteredUsers.add(user);
                    }
                }
            }
            
            logger.info("Filtered {} users between {} and {}", filteredUsers.size(), startDate, endDate);
            return filteredUsers;
        } catch (DateTimeParseException e) {
            logger.error("Date format error: {}", e.getMessage(), e);
            return Collections.emptyList();
        } catch (Exception e) {
            logger.error("Error filtering users: {}", e.getMessage(), e);
            return Collections.emptyList();
        }
    }
    
    /**
     * Calculate statistics on user data.
     * 
     * @param usersToProcess List of users to analyze, uses this.users if null
     * @return Map containing statistics
     */
    public Map<String, Object> calculateStatistics(List<Map<String, Object>> usersToProcess) {
        if (usersToProcess == null) {
            usersToProcess = this.users;
        }
        
        if (usersToProcess.isEmpty()) {
            logger.warn("No users to calculate statistics");
            return Collections.emptyMap();
        }
        
        try {
            // Count users by domain
            Map<String, Integer> domains = new HashMap<>();
            
            for (Map<String, Object> user : usersToProcess) {
                if (user.containsKey("email")) {
                    String email = user.get("email").toString();
                    String domain = email.substring(email.lastIndexOf('@') + 1);
                    domains.put(domain, domains.getOrDefault(domain, 0) + 1);
                }
            }
            
            // Get most common domain
            Map.Entry<String, Integer> mostCommonDomain = domains.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .orElse(new AbstractMap.SimpleEntry<>("", 0));
            
            // Calculate average username length
            double avgUsernameLength = usersToProcess.stream()
                    .filter(user -> user.containsKey("username"))
                    .mapToInt(user -> user.get("username").toString().length())
                    .average()
                    .orElse(0.0);
            
            Map<String, Object> statistics = new HashMap<>();
            statistics.put("total_users", usersToProcess.size());
            statistics.put("domains", domains);
            statistics.put("most_common_domain", mostCommonDomain.getKey());
            statistics.put("most_common_domain_count", mostCommonDomain.getValue());
            statistics.put("avg_username_length", avgUsernameLength);
            
            this.stats = statistics;
            logger.info("Calculated statistics for {} users", usersToProcess.size());
            return statistics;
        } catch (Exception e) {
            logger.error("Error calculating statistics: {}", e.getMessage(), e);
            return Collections.emptyMap();
        }
    }
    
    /**
     * Export results to a JSON file.
     * 
     * @param outputFile Name of the output file
     * @param data Data to export
     * @return true if data was exported successfully, false otherwise
     */
    public boolean exportResults(String outputFile, Map<String, Object> data) {
        try {
            Path outputPath = Paths.get(dataDir, outputFile);
            logger.info("Exporting results to {}", outputPath);
            
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(outputPath.toFile(), data);
            
            logger.info("Results exported successfully");
            return true;
        } catch (IOException e) {
            logger.error("Error exporting results: {}", e.getMessage(), e);
            return false;
        }
    }
    
    /**
     * Process data from input file and export results.
     * 
     * @param inputFile Input JSON file
     * @param outputFile Output JSON file
     * @param startDate Optional start date filter
     * @param endDate Optional end date filter
     * @return true if processing was successful, false otherwise
     */
    public boolean processData(String inputFile, String outputFile, String startDate, String endDate) {
        if (!loadData(inputFile)) {
            return false;
        }
        
        List<Map<String, Object>> usersToProcess = this.users;
        
        // Apply date filter if provided
        if (startDate != null && endDate != null) {
            usersToProcess = filterUsersByDate(startDate, endDate);
            if (usersToProcess.isEmpty()) {
                logger.warn("No users match the date filter");
                return false;
            }
        }
        
        Map<String, Object> statistics = calculateStatistics(usersToProcess);
        if (statistics.isEmpty()) {
            return false;
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("processed_at", LocalDateTime.now().format(DATETIME_FORMATTER));
        result.put("input_file", inputFile);
        result.put("total_records", this.users.size());
        result.put("processed_records", usersToProcess.size());
        result.put("statistics", statistics);
        
        return exportResults(outputFile, result);
    }
    
    /**
     * Process data without date filtering.
     * 
     * @param inputFile Input JSON file
     * @param outputFile Output JSON file
     * @return true if processing was successful, false otherwise
     */
    public boolean processData(String inputFile, String outputFile) {
        return processData(inputFile, outputFile, null, null);
    }
    
    /**
     * Main method for testing.
     * 
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        DataProcessor processor = new DataProcessor();
        boolean success = processor.processData("users.json", "stats.json", "2023-01-01", "2023-12-31");
        System.out.println("Processing " + (success ? "successful" : "failed"));
    }
}