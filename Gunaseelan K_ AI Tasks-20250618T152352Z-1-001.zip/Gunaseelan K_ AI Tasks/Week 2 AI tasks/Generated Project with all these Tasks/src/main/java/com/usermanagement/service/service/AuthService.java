package com.usermanagement.service.service;

import com.usermanagement.service.dto.LoginRequest;
import com.usermanagement.service.dto.LoginResponse;
import com.usermanagement.service.dto.UserRegistrationDto;

public interface AuthService {
    LoginResponse login(LoginRequest loginRequest);
    void register(UserRegistrationDto registrationDto);
}