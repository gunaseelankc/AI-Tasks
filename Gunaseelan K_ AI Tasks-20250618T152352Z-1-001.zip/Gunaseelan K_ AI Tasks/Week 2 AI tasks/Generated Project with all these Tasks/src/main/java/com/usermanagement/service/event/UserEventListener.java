package com.usermanagement.service.event;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Event listener that handles user-related events.
 * This is a concrete implementation of the Observer pattern.
 */
@Component
@Slf4j
public class UserEventListener implements EventListener {
    
    @Override
    public void onEvent(Event event) {
        switch (event.getType()) {
            case USER_CREATED:
                handleUserCreated(event);
                break;
            case USER_UPDATED:
                handleUserUpdated(event);
                break;
            case USER_DELETED:
                handleUserDeleted(event);
                break;
            case USER_LOGIN:
                handleUserLogin(event);
                break;
            default:
                log.warn("Received unexpected event type: {}", event.getType());
        }
    }
    
    private void handleUserCreated(Event event) {
        log.info("User created: {}", event.getData().get("username"));
        // In a real application, we might send a welcome email, etc.
    }
    
    private void handleUserUpdated(Event event) {
        log.info("User updated: {}", event.getData().get("username"));
        // In a real application, we might update related systems, etc.
    }
    
    private void handleUserDeleted(Event event) {
        log.info("User deleted: {}", event.getData().get("username"));
        // In a real application, we might clean up related data, etc.
    }
    
    private void handleUserLogin(Event event) {
        log.info("User login: {}", event.getData().get("username"));
        // In a real application, we might update last login time, etc.
    }
    
    @Override
    public EventType getEventType() {
        // This listener is interested in user events only
        return EventType.USER_CREATED; // We'll handle filtering in the onEvent method
    }
}