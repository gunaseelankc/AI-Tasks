package com.usermanagement.service.legacy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Legacy user service with code smells and anti-patterns.
 * This class is intentionally designed with issues for modernization.
 */
public class LegacyUserService {
    
    private static String DB_URL = "jdbc:postgresql://localhost:5432/userdb";
    private static String DB_USER = "postgres";
    private static String DB_PASSWORD = "postgres";
    
    public boolean createUser(String username, String email, String password) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Check if user exists
            String checkSql = "SELECT COUNT(*) FROM users WHERE username = '" + username + "' OR email = '" + email + "'";
            Statement checkStmt = conn.createStatement();
            ResultSet rs = checkStmt.executeQuery(checkSql);
            rs.next();
            int count = rs.getInt(1);
            
            if (count > 0) {
                System.out.println("User already exists with username or email");
                return false;
            }
            
            // Insert user
            String sql = "INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, password); // Storing plain password
            stmt.setDate(4, new java.sql.Date(new Date().getTime()));
            
            int rowsAffected = stmt.executeUpdate();
            
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public Map<String, Object> getUserByUsername(String username) {
        Connection conn = null;
        Statement stmt = null;
        Map<String, Object> user = null;
        
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Get user
            String sql = "SELECT * FROM users WHERE username = '" + username + "'";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            if (rs.next()) {
                user = new HashMap<>();
                user.put("id", rs.getString("id"));
                user.put("username", rs.getString("username"));
                user.put("email", rs.getString("email"));
                user.put("password", rs.getString("password")); // Returning password
                user.put("created_at", rs.getDate("created_at"));
            }
            
            return user;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public List<Map<String, Object>> getAllUsers() {
        Connection conn = null;
        Statement stmt = null;
        List<Map<String, Object>> users = new ArrayList<>();
        
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Get all users
            String sql = "SELECT * FROM users";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Map<String, Object> user = new HashMap<>();
                user.put("id", rs.getString("id"));
                user.put("username", rs.getString("username"));
                user.put("email", rs.getString("email"));
                user.put("password", rs.getString("password")); // Returning password
                user.put("created_at", rs.getDate("created_at"));
                users.add(user);
            }
            
            return users;
        } catch (Exception e) {
            e.printStackTrace();
            return users;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean updateUser(String id, String username, String email, String password) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Update user
            String sql = "UPDATE users SET username = '" + username + "', email = '" + email + 
                    "', password = '" + password + "', updated_at = NOW() WHERE id = '" + id + "'";
            stmt = conn.prepareStatement(sql);
            
            int rowsAffected = stmt.executeUpdate();
            
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean deleteUser(String id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Delete user
            String sql = "DELETE FROM users WHERE id = '" + id + "'";
            stmt = conn.prepareStatement(sql);
            
            int rowsAffected = stmt.executeUpdate();
            
            return rowsAffected > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean authenticateUser(String username, String password) {
        Connection conn = null;
        Statement stmt = null;
        
        try {
            // Connect to database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            
            // Check credentials
            String sql = "SELECT COUNT(*) FROM users WHERE username = '" + username + 
                    "' AND password = '" + password + "'";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            int count = rs.getInt(1);
            
            return count > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}