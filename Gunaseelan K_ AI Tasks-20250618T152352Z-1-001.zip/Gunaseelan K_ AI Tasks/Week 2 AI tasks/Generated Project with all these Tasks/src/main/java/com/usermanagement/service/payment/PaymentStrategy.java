package com.usermanagement.service.payment;

import java.math.BigDecimal;

/**
 * Strategy interface for different payment processing methods.
 * This interface defines the contract for various payment strategies.
 */
public interface PaymentStrategy {
    
    /**
     * Process a payment with the given amount.
     * 
     * @param amount The payment amount
     * @param currency The currency code (e.g., USD, EUR)
     * @return PaymentResult containing transaction details and status
     */
    PaymentResult processPayment(BigDecimal amount, String currency);
    
    /**
     * Validate if the payment method is available for the given parameters.
     * 
     * @param amount The payment amount
     * @param currency The currency code
     * @return true if the payment method is available, false otherwise
     */
    boolean isAvailable(BigDecimal amount, String currency);
    
    /**
     * Get the name of the payment method.
     * 
     * @return String representing the payment method name
     */
    String getMethodName();
}