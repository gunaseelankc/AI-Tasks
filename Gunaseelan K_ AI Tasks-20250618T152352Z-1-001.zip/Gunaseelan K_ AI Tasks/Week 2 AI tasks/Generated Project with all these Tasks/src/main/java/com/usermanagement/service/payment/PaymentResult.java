package com.usermanagement.service.payment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Represents the result of a payment processing operation.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResult {
    
    private String transactionId;
    private PaymentStatus status;
    private BigDecimal amount;
    private String currency;
    private String paymentMethod;
    private LocalDateTime timestamp;
    private String errorMessage;
    
    /**
     * Enum representing possible payment statuses.
     */
    public enum PaymentStatus {
        SUCCESS,
        FAILED,
        PENDING,
        CANCELLED
    }
    
    /**
     * Factory method to create a successful payment result.
     */
    public static PaymentResult success(String transactionId, BigDecimal amount, String currency, String paymentMethod) {
        return PaymentResult.builder()
                .transactionId(transactionId)
                .status(PaymentStatus.SUCCESS)
                .amount(amount)
                .currency(currency)
                .paymentMethod(paymentMethod)
                .timestamp(LocalDateTime.now())
                .build();
    }
    
    /**
     * Factory method to create a failed payment result.
     */
    public static PaymentResult failed(String errorMessage, BigDecimal amount, String currency, String paymentMethod) {
        return PaymentResult.builder()
                .status(PaymentStatus.FAILED)
                .errorMessage(errorMessage)
                .amount(amount)
                .currency(currency)
                .paymentMethod(paymentMethod)
                .timestamp(LocalDateTime.now())
                .build();
    }
}