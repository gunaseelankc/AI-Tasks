package com.usermanagement.service.service.impl;

import com.usermanagement.service.dto.LoginRequest;
import com.usermanagement.service.dto.LoginResponse;
import com.usermanagement.service.dto.UserRegistrationDto;
import com.usermanagement.service.security.JwtTokenUtil;
import com.usermanagement.service.service.AuthService;
import com.usermanagement.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenUtil jwtTokenUtil;
    private final UserService userService;

    @Override
    public LoginResponse login(LoginRequest loginRequest) {
        log.debug("Authenticating user: {}", loginRequest.getUsername());
        
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                )
        );
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String jwt = jwtTokenUtil.generateToken(userDetails);
        
        log.info("User authenticated successfully: {}", loginRequest.getUsername());
        
        return new LoginResponse(jwt, userDetails.getUsername());
    }

    @Override
    public void register(UserRegistrationDto registrationDto) {
        log.debug("Registering new user: {}", registrationDto.getUsername());
        userService.createUser(registrationDto);
        log.info("User registered successfully: {}", registrationDto.getUsername());
    }
}