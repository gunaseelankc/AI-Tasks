package com.usermanagement.service.event;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Event publisher that implements the Observer pattern.
 * This class manages event listeners and publishes events to them.
 */
@Component
@Slf4j
public class EventPublisher {
    
    private final Map<EventType, List<EventListener>> listeners = new HashMap<>();
    private final ExecutorService executorService = Executors.newFixedThreadPool(5);
    
    /**
     * Register a listener for a specific event type.
     * 
     * @param listener The listener to register
     */
    public void registerListener(EventListener listener) {
        EventType eventType = listener.getEventType();
        listeners.computeIfAbsent(eventType, k -> new ArrayList<>()).add(listener);
        log.info("Registered listener {} for event type {}", listener.getClass().getSimpleName(), eventType);
    }
    
    /**
     * Unregister a listener.
     * 
     * @param listener The listener to unregister
     */
    public void unregisterListener(EventListener listener) {
        EventType eventType = listener.getEventType();
        if (listeners.containsKey(eventType)) {
            listeners.get(eventType).remove(listener);
            log.info("Unregistered listener {} for event type {}", listener.getClass().getSimpleName(), eventType);
        }
    }
    
    /**
     * Publish an event to all registered listeners.
     * Events are delivered asynchronously to listeners.
     * 
     * @param event The event to publish
     */
    public void publishEvent(Event event) {
        log.debug("Publishing event: {}", event);
        
        List<EventListener> eventListeners = listeners.getOrDefault(event.getType(), new ArrayList<>());
        
        if (eventListeners.isEmpty()) {
            log.debug("No listeners registered for event type: {}", event.getType());
            return;
        }
        
        for (EventListener listener : eventListeners) {
            // Deliver events asynchronously to prevent blocking
            executorService.submit(() -> {
                try {
                    log.debug("Delivering event {} to listener {}", 
                            event.getId(), listener.getClass().getSimpleName());
                    listener.onEvent(event);
                } catch (Exception e) {
                    log.error("Error delivering event to listener: {}", e.getMessage(), e);
                }
            });
        }
    }
    
    /**
     * Shutdown the event publisher and its thread pool.
     */
    public void shutdown() {
        executorService.shutdown();
    }
}