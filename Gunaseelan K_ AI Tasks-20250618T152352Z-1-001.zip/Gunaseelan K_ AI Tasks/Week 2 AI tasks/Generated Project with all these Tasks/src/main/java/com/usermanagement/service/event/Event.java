package com.usermanagement.service.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Represents an event in the system.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Event {
    
    private String id;
    private EventType type;
    private String source;
    private LocalDateTime timestamp;
    private Map<String, Object> data;
    
    /**
     * Factory method to create a new event.
     */
    public static Event create(EventType type, String source, Map<String, Object> data) {
        return Event.builder()
                .id(UUID.randomUUID().toString())
                .type(type)
                .source(source)
                .timestamp(LocalDateTime.now())
                .data(data)
                .build();
    }
}