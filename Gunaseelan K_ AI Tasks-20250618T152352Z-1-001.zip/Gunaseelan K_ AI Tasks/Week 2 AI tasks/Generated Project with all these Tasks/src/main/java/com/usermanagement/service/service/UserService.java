package com.usermanagement.service.service;

import com.usermanagement.service.dto.UserDto;
import com.usermanagement.service.dto.UserRegistrationDto;

import java.util.List;
import java.util.UUID;

public interface UserService {
    UserDto createUser(UserRegistrationDto registrationDto);
    UserDto getUserById(UUID id);
    UserDto getUserByUsername(String username);
    List<UserDto> getAllUsers();
    UserDto updateUser(UUID id, UserRegistrationDto userDto);
    void deleteUser(UUID id);
}