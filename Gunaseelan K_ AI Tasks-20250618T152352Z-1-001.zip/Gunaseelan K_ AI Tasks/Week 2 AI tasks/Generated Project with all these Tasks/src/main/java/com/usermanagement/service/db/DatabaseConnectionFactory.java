package com.usermanagement.service.db;

/**
 * Factory interface for creating database connections.
 * This is part of the Factory Pattern implementation.
 */
public interface DatabaseConnectionFactory {
    
    /**
     * Create a database connection.
     * 
     * @return A database connection
     * @throws DatabaseException if connection creation fails
     */
    DatabaseConnection createConnection() throws DatabaseException;
    
    /**
     * Get the database type this factory creates connections for.
     * 
     * @return The database type
     */
    DatabaseType getDatabaseType();
}