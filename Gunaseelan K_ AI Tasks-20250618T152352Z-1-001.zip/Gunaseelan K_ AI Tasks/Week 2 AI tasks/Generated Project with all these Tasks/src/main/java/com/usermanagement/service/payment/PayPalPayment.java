package com.usermanagement.service.payment;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * PayPal payment strategy implementation.
 */
@Component
@Slf4j
public class PayPalPayment implements PaymentStrategy {

    // List of supported currencies for PayPal
    private static final List<String> SUPPORTED_CURRENCIES = Arrays.asList("USD", "EUR", "GBP", "CAD", "AUD");

    @Override
    public PaymentResult processPayment(BigDecimal amount, String currency) {
        log.info("Processing PayPal payment of {} {}", amount, currency);
        
        // Validate currency is supported
        if (!SUPPORTED_CURRENCIES.contains(currency)) {
            log.error("PayPal payment failed: Currency {} not supported", currency);
            return PaymentResult.failed("Currency not supported by PayPal", amount, currency, getMethodName());
        }
        
        // Simulate PayPal API call
        try {
            // In a real implementation, this would call PayPal's API
            Thread.sleep(700); // Simulate network delay
            
            // Generate a transaction ID
            String transactionId = "PP-" + UUID.randomUUID().toString();
            
            log.info("PayPal payment successful: {}", transactionId);
            return PaymentResult.success(transactionId, amount, currency, getMethodName());
        } catch (Exception e) {
            log.error("PayPal payment failed", e);
            return PaymentResult.failed("PayPal processing error: " + e.getMessage(), 
                    amount, currency, getMethodName());
        }
    }

    @Override
    public boolean isAvailable(BigDecimal amount, String currency) {
        // Check if currency is supported and amount is within limits
        boolean isAvailable = SUPPORTED_CURRENCIES.contains(currency) && 
                             amount.compareTo(BigDecimal.valueOf(10000)) <= 0;
        log.debug("PayPal payment availability check: {}", isAvailable);
        return isAvailable;
    }

    @Override
    public String getMethodName() {
        return "PayPal";
    }
}