package com.usermanagement.service.legacy;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.*;

/**
 * Modernized version of the legacy user service.
 * This class demonstrates best practices and fixes issues from the legacy code.
 */
@Service
@Slf4j
public class ModernizedUserService {
    
    private final DataSource dataSource;
    private final PasswordEncoder passwordEncoder;
    
    @Autowired
    public ModernizedUserService(DataSource dataSource, PasswordEncoder passwordEncoder) {
        this.dataSource = dataSource;
        this.passwordEncoder = passwordEncoder;
    }
    
    /**
     * Create a new user with the given details.
     * 
     * @param username The username
     * @param email The email address
     * @param password The password (will be encrypted)
     * @return true if the user was created, false otherwise
     * @throws SQLException if a database error occurs
     */
    @Transactional
    public boolean createUser(String username, String email, String password) throws SQLException {
        // Input validation
        if (username == null || username.trim().isEmpty() || 
            email == null || email.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Username, email, and password are required");
        }
        
        try (Connection conn = dataSource.getConnection()) {
            // Check if user exists using prepared statement to prevent SQL injection
            String checkSql = "SELECT COUNT(*) FROM users WHERE username = ? OR email = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, username);
                checkStmt.setString(2, email);
                
                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        log.info("User already exists with username or email: {}, {}", username, email);
                        return false;
                    }
                }
            }
            
            // Insert user with encrypted password
            String sql = "INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, email);
                stmt.setString(3, passwordEncoder.encode(password)); // Encrypt password
                stmt.setObject(4, LocalDateTime.now());
                
                int rowsAffected = stmt.executeUpdate();
                log.info("Created user: {}, rows affected: {}", username, rowsAffected);
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            log.error("Error creating user: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    /**
     * Get a user by username.
     * 
     * @param username The username to look up
     * @return Map containing user details (without password) or null if not found
     * @throws SQLException if a database error occurs
     */
    public Map<String, Object> getUserByUsername(String username) throws SQLException {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username is required");
        }
        
        try (Connection conn = dataSource.getConnection()) {
            String sql = "SELECT id, username, email, created_at, updated_at FROM users WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        Map<String, Object> user = new HashMap<>();
                        user.put("id", rs.getObject("id"));
                        user.put("username", rs.getString("username"));
                        user.put("email", rs.getString("email"));
                        user.put("created_at", rs.getObject("created_at"));
                        user.put("updated_at", rs.getObject("updated_at"));
                        
                        return user;
                    }
                    return null;
                }
            }
        } catch (SQLException e) {
            log.error("Error getting user by username: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    /**
     * Get all users.
     * 
     * @return List of maps containing user details (without passwords)
     * @throws SQLException if a database error occurs
     */
    public List<Map<String, Object>> getAllUsers() throws SQLException {
        List<Map<String, Object>> users = new ArrayList<>();
        
        try (Connection conn = dataSource.getConnection()) {
            String sql = "SELECT id, username, email, created_at, updated_at FROM users";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Map<String, Object> user = new HashMap<>();
                        user.put("id", rs.getObject("id"));
                        user.put("username", rs.getString("username"));
                        user.put("email", rs.getString("email"));
                        user.put("created_at", rs.getObject("created_at"));
                        user.put("updated_at", rs.getObject("updated_at"));
                        users.add(user);
                    }
                }
            }
            return users;
        } catch (SQLException e) {
            log.error("Error getting all users: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    /**
     * Update a user's details.
     * 
     * @param id The user ID
     * @param username The new username
     * @param email The new email
     * @param password The new password (optional, will be encrypted if provided)
     * @return true if the user was updated, false otherwise
     * @throws SQLException if a database error occurs
     */
    @Transactional
    public boolean updateUser(UUID id, String username, String email, String password) throws SQLException {
        if (id == null || username == null || username.trim().isEmpty() || email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("ID, username, and email are required");
        }
        
        try (Connection conn = dataSource.getConnection()) {
            StringBuilder sqlBuilder = new StringBuilder("UPDATE users SET username = ?, email = ?");
            
            // Only update password if provided
            if (password != null && !password.trim().isEmpty()) {
                sqlBuilder.append(", password = ?");
            }
            
            sqlBuilder.append(", updated_at = ? WHERE id = ?");
            
            try (PreparedStatement stmt = conn.prepareStatement(sqlBuilder.toString())) {
                stmt.setString(1, username);
                stmt.setString(2, email);
                
                int paramIndex = 3;
                if (password != null && !password.trim().isEmpty()) {
                    stmt.setString(paramIndex++, passwordEncoder.encode(password));
                }
                
                stmt.setObject(paramIndex++, LocalDateTime.now());
                stmt.setObject(paramIndex, id);
                
                int rowsAffected = stmt.executeUpdate();
                log.info("Updated user with ID: {}, rows affected: {}", id, rowsAffected);
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            log.error("Error updating user: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    /**
     * Delete a user.
     * 
     * @param id The user ID
     * @return true if the user was deleted, false otherwise
     * @throws SQLException if a database error occurs
     */
    @Transactional
    public boolean deleteUser(UUID id) throws SQLException {
        if (id == null) {
            throw new IllegalArgumentException("ID is required");
        }
        
        try (Connection conn = dataSource.getConnection()) {
            String sql = "DELETE FROM users WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setObject(1, id);
                
                int rowsAffected = stmt.executeUpdate();
                log.info("Deleted user with ID: {}, rows affected: {}", id, rowsAffected);
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            log.error("Error deleting user: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    /**
     * Authenticate a user with username and password.
     * 
     * @param username The username
     * @param password The password
     * @return true if authentication is successful, false otherwise
     * @throws SQLException if a database error occurs
     */
    public boolean authenticateUser(String username, String password) throws SQLException {
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Username and password are required");
        }
        
        try (Connection conn = dataSource.getConnection()) {
            String sql = "SELECT password FROM users WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        String storedPassword = rs.getString("password");
                        // Use password encoder to verify password
                        boolean authenticated = passwordEncoder.matches(password, storedPassword);
                        log.info("Authentication attempt for user {}: {}", username, authenticated ? "successful" : "failed");
                        return authenticated;
                    }
                    return false;
                }
            }
        } catch (SQLException e) {
            log.error("Error authenticating user: {}", e.getMessage(), e);
            throw e;
        }
    }
}