package com.usermanagement.service.event;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Configuration class for the event system.
 * Registers all event listeners with the event publisher.
 */
@Configuration
@RequiredArgsConstructor
@Slf4j
public class EventConfig {
    
    private final EventPublisher eventPublisher;
    private final List<EventListener> eventListeners;
    
    /**
     * Register all event listeners with the event publisher.
     */
    @PostConstruct
    public void init() {
        log.info("Initializing event system with {} listeners", eventListeners.size());
        
        for (EventListener listener : eventListeners) {
            eventPublisher.registerListener(listener);
        }
    }
    
    /**
     * Shutdown the event publisher when the application is shutting down.
     */
    @PreDestroy
    public void destroy() {
        log.info("Shutting down event system");
        eventPublisher.shutdown();
    }
}