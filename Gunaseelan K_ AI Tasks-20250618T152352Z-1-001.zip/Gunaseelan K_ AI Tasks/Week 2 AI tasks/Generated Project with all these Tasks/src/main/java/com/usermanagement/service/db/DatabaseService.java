package com.usermanagement.service.db;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service that uses the Factory Pattern to create and manage database connections.
 */
@Service
@Slf4j
public class DatabaseService {
    
    private final Map<DatabaseType, DatabaseConnectionFactory> factories = new HashMap<>();
    
    @Value("${spring.datasource.type:H2}")
    private String databaseType;
    
    /**
     * Constructor that initializes the service with available factories.
     * 
     * @param connectionFactories List of available database connection factories
     */
    public DatabaseService(List<DatabaseConnectionFactory> connectionFactories) {
        for (DatabaseConnectionFactory factory : connectionFactories) {
            factories.put(factory.getDatabaseType(), factory);
            log.info("Registered database connection factory for {}", factory.getDatabaseType());
        }
    }
    
    /**
     * Get a database connection of the configured type.
     * 
     * @return A database connection
     * @throws DatabaseException if creating the connection fails
     */
    public DatabaseConnection getConnection() throws DatabaseException {
        DatabaseType type = DatabaseType.valueOf(databaseType.toUpperCase());
        return getConnection(type);
    }
    
    /**
     * Get a database connection of the specified type.
     * 
     * @param type The database type
     * @return A database connection
     * @throws DatabaseException if creating the connection fails
     */
    public DatabaseConnection getConnection(DatabaseType type) throws DatabaseException {
        DatabaseConnectionFactory factory = factories.get(type);
        
        if (factory == null) {
            throw new DatabaseException("No factory registered for database type: " + type);
        }
        
        return factory.createConnection();
    }
}