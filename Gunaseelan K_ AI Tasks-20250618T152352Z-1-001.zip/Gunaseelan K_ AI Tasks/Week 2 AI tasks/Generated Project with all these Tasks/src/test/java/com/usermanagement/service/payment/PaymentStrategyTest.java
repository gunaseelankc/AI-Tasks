package com.usermanagement.service.payment;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PaymentStrategyTest {

    @Mock
    private CreditCardPayment creditCardPayment;

    @Mock
    private PayPalPayment payPalPayment;

    @Mock
    private BankTransferPayment bankTransferPayment;

    @InjectMocks
    private PaymentProcessor paymentProcessor;

    @Test
    void testGetAvailablePaymentMethods() {
        // Given
        BigDecimal amount = BigDecimal.valueOf(1000);
        String currency = "USD";
        
        when(creditCardPayment.isAvailable(amount, currency)).thenReturn(true);
        when(creditCardPayment.getMethodName()).thenReturn("Credit Card");
        
        when(payPalPayment.isAvailable(amount, currency)).thenReturn(true);
        when(payPalPayment.getMethodName()).thenReturn("PayPal");
        
        when(bankTransferPayment.isAvailable(amount, currency)).thenReturn(true);
        when(bankTransferPayment.getMethodName()).thenReturn("Bank Transfer");
        
        // When
        List<String> availableMethods = paymentProcessor.getAvailablePaymentMethods(amount, currency);
        
        // Then
        assertEquals(3, availableMethods.size());
        assertTrue(availableMethods.contains("Credit Card"));
        assertTrue(availableMethods.contains("PayPal"));
        assertTrue(availableMethods.contains("Bank Transfer"));
        
        verify(creditCardPayment).isAvailable(amount, currency);
        verify(payPalPayment).isAvailable(amount, currency);
        verify(bankTransferPayment).isAvailable(amount, currency);
    }

    @Test
    void testProcessPayment_CreditCard() {
        // Given
        BigDecimal amount = BigDecimal.valueOf(500);
        String currency = "USD";
        String paymentMethod = "Credit Card";
        
        when(creditCardPayment.getMethodName()).thenReturn(paymentMethod);
        when(creditCardPayment.isAvailable(amount, currency)).thenReturn(true);
        
        PaymentResult expectedResult = PaymentResult.success("test-id", amount, currency, paymentMethod);
        when(creditCardPayment.processPayment(amount, currency)).thenReturn(expectedResult);
        
        // When
        PaymentResult result = paymentProcessor.processPayment(amount, currency, paymentMethod);
        
        // Then
        assertNotNull(result);
        assertEquals(PaymentResult.PaymentStatus.SUCCESS, result.getStatus());
        assertEquals(paymentMethod, result.getPaymentMethod());
        
        verify(creditCardPayment).isAvailable(amount, currency);
        verify(creditCardPayment).processPayment(amount, currency);
    }

    @Test
    void testProcessPayment_PaymentMethodNotAvailable() {
        // Given
        BigDecimal amount = BigDecimal.valueOf(100000);
        String currency = "USD";
        String paymentMethod = "PayPal";
        
        when(payPalPayment.getMethodName()).thenReturn(paymentMethod);
        when(payPalPayment.isAvailable(amount, currency)).thenReturn(false);
        
        // When & Then
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            paymentProcessor.processPayment(amount, currency, paymentMethod);
        });
        
        assertTrue(exception.getMessage().contains("not available"));
        
        verify(payPalPayment).isAvailable(amount, currency);
        verify(payPalPayment, never()).processPayment(amount, currency);
    }

    @Test
    void testProcessPayment_InvalidPaymentMethod() {
        // Given
        BigDecimal amount = BigDecimal.valueOf(500);
        String currency = "USD";
        String paymentMethod = "Bitcoin";
        
        when(creditCardPayment.getMethodName()).thenReturn("Credit Card");
        when(payPalPayment.getMethodName()).thenReturn("PayPal");
        when(bankTransferPayment.getMethodName()).thenReturn("Bank Transfer");
        
        // When & Then
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            paymentProcessor.processPayment(amount, currency, paymentMethod);
        });
        
        assertTrue(exception.getMessage().contains("not found"));
    }
}