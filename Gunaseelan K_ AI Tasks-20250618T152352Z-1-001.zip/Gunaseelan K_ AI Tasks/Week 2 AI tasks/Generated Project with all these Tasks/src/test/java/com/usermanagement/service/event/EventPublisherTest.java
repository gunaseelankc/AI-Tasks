package com.usermanagement.service.event;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EventPublisherTest {

    private EventPublisher eventPublisher;

    @Mock
    private EventListener userEventListener;

    @Mock
    private EventListener loggingEventListener;

    @BeforeEach
    void setUp() {
        eventPublisher = new EventPublisher();
        
        when(userEventListener.getEventType()).thenReturn(EventType.USER_CREATED);
        when(loggingEventListener.getEventType()).thenReturn(null); // Interested in all events
        
        eventPublisher.registerListener(userEventListener);
        eventPublisher.registerListener(loggingEventListener);
    }

    @Test
    void testPublishEvent_UserCreated() throws InterruptedException {
        // Given
        Map<String, Object> data = new HashMap<>();
        data.put("username", "testuser");
        data.put("email", "test@example.com");
        
        Event event = Event.create(EventType.USER_CREATED, "test", data);
        
        // Set up a latch to wait for async event delivery
        CountDownLatch latch = new CountDownLatch(2); // Expect 2 deliveries
        
        doAnswer(invocation -> {
            latch.countDown();
            return null;
        }).when(userEventListener).onEvent(event);
        
        doAnswer(invocation -> {
            latch.countDown();
            return null;
        }).when(loggingEventListener).onEvent(event);
        
        // When
        eventPublisher.publishEvent(event);
        
        // Then
        assertTrue(latch.await(1, TimeUnit.SECONDS), "Event should be delivered within timeout");
        
        verify(userEventListener).onEvent(event);
        verify(loggingEventListener).onEvent(event);
    }

    @Test
    void testPublishEvent_PaymentProcessed() throws InterruptedException {
        // Given
        Map<String, Object> data = new HashMap<>();
        data.put("amount", "100.00");
        data.put("currency", "USD");
        
        Event event = Event.create(EventType.PAYMENT_PROCESSED, "test", data);
        
        // Set up a latch to wait for async event delivery
        CountDownLatch latch = new CountDownLatch(1); // Expect 1 delivery (only logging listener)
        
        doAnswer(invocation -> {
            latch.countDown();
            return null;
        }).when(loggingEventListener).onEvent(event);
        
        // When
        eventPublisher.publishEvent(event);
        
        // Then
        assertTrue(latch.await(1, TimeUnit.SECONDS), "Event should be delivered within timeout");
        
        verify(userEventListener, never()).onEvent(event); // User listener shouldn't receive this event
        verify(loggingEventListener).onEvent(event);
    }

    @Test
    void testUnregisterListener() throws InterruptedException {
        // Given
        eventPublisher.unregisterListener(userEventListener);
        
        Map<String, Object> data = new HashMap<>();
        data.put("username", "testuser");
        
        Event event = Event.create(EventType.USER_CREATED, "test", data);
        
        // Set up a latch to wait for async event delivery
        CountDownLatch latch = new CountDownLatch(1); // Expect 1 delivery (only logging listener)
        
        doAnswer(invocation -> {
            latch.countDown();
            return null;
        }).when(loggingEventListener).onEvent(event);
        
        // When
        eventPublisher.publishEvent(event);
        
        // Then
        assertTrue(latch.await(1, TimeUnit.SECONDS), "Event should be delivered within timeout");
        
        verify(userEventListener, never()).onEvent(event); // Unregistered listener shouldn't receive events
        verify(loggingEventListener).onEvent(event);
    }
}