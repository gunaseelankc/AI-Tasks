package com.usermanagement.service.db;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DatabaseFactoryTest {

    @Mock
    private PostgreSQLConnectionFactory postgresFactory;

    @Mock
    private H2ConnectionFactory h2Factory;

    @Mock
    private DatabaseConnection mockConnection;

    @InjectMocks
    private DatabaseService databaseService;

    @Test
    void testGetConnection_PostgreSQL() throws DatabaseException {
        // Given
        when(postgresFactory.getDatabaseType()).thenReturn(DatabaseType.POSTGRESQL);
        when(h2Factory.getDatabaseType()).thenReturn(DatabaseType.H2);
        
        // Initialize the service manually since we're using mocks
        databaseService = new DatabaseService(Arrays.asList(postgresFactory, h2Factory));
        ReflectionTestUtils.setField(databaseService, "databaseType", "POSTGRESQL");
        
        when(postgresFactory.createConnection()).thenReturn(mockConnection);
        when(mockConnection.getDatabaseType()).thenReturn(DatabaseType.POSTGRESQL);
        
        // When
        DatabaseConnection connection = databaseService.getConnection();
        
        // Then
        assertNotNull(connection);
        assertEquals(DatabaseType.POSTGRESQL, connection.getDatabaseType());
        
        verify(postgresFactory).createConnection();
        verify(h2Factory, never()).createConnection();
    }

    @Test
    void testGetConnection_H2() throws DatabaseException {
        // Given
        when(postgresFactory.getDatabaseType()).thenReturn(DatabaseType.POSTGRESQL);
        when(h2Factory.getDatabaseType()).thenReturn(DatabaseType.H2);
        
        // Initialize the service manually since we're using mocks
        databaseService = new DatabaseService(Arrays.asList(postgresFactory, h2Factory));
        ReflectionTestUtils.setField(databaseService, "databaseType", "H2");
        
        when(h2Factory.createConnection()).thenReturn(mockConnection);
        when(mockConnection.getDatabaseType()).thenReturn(DatabaseType.H2);
        
        // When
        DatabaseConnection connection = databaseService.getConnection();
        
        // Then
        assertNotNull(connection);
        assertEquals(DatabaseType.H2, connection.getDatabaseType());
        
        verify(h2Factory).createConnection();
        verify(postgresFactory, never()).createConnection();
    }

    @Test
    void testGetConnection_SpecificType() throws DatabaseException {
        // Given
        when(postgresFactory.getDatabaseType()).thenReturn(DatabaseType.POSTGRESQL);
        when(h2Factory.getDatabaseType()).thenReturn(DatabaseType.H2);
        
        // Initialize the service manually since we're using mocks
        databaseService = new DatabaseService(Arrays.asList(postgresFactory, h2Factory));
        
        when(postgresFactory.createConnection()).thenReturn(mockConnection);
        when(mockConnection.getDatabaseType()).thenReturn(DatabaseType.POSTGRESQL);
        
        // When
        DatabaseConnection connection = databaseService.getConnection(DatabaseType.POSTGRESQL);
        
        // Then
        assertNotNull(connection);
        assertEquals(DatabaseType.POSTGRESQL, connection.getDatabaseType());
        
        verify(postgresFactory).createConnection();
        verify(h2Factory, never()).createConnection();
    }

    @Test
    void testGetConnection_UnsupportedType() {
        // Given
        when(postgresFactory.getDatabaseType()).thenReturn(DatabaseType.POSTGRESQL);
        when(h2Factory.getDatabaseType()).thenReturn(DatabaseType.H2);
        
        // Initialize the service manually since we're using mocks
        databaseService = new DatabaseService(Arrays.asList(postgresFactory, h2Factory));
        
        // When & Then
        Exception exception = assertThrows(DatabaseException.class, () -> {
            databaseService.getConnection(DatabaseType.MYSQL);
        });
        
        assertTrue(exception.getMessage().contains("No factory registered"));
    }
}