# User Management Microservice

A production-ready RESTful API for user management built with Spring Boot.

## Features

- User registration and authentication
- JWT-based security
- RESTful API with proper HTTP methods
- H2 in-memory database with JPA
- Centralized error handling
- Input validation
- Comprehensive logging

## Technology Stack

- Java 17
- Spring Boot 3.x
- Spring Data JPA
- Spring Security with JWT
- H2 Database
- JUnit 5 & Mockito for testing

## Project Structure

```
src/
├── main/
│   ├── java/
│   │   └── com/
│   │       └── usermanagement/
│   │           └── service/
│   │               ├── config/           # Configuration classes
│   │               ├── controller/       # REST controllers
│   │               ├── dto/              # Data Transfer Objects
│   │               ├── exception/        # Exception handling
│   │               ├── model/            # JPA entities
│   │               ├── repository/       # Spring Data repositories
│   │               ├── security/         # Security configuration
│   │               ├── service/          # Business logic
│   │               └── UserServiceApplication.java
│   └── resources/
│       └── application.yml               # Application configuration
└── test/
    └── java/
        └── com/
            └── usermanagement/
                └── service/
                    ├── controller/       # Controller tests
                    └── service/          # Service tests
```

## Setup and Installation

### Prerequisites

- Java 17 or higher
- Maven

### Running the Application

```bash
# Using Maven
mvn spring-boot:run
```

The application will start on port 8080 with context path `/api`.

### H2 Database Console

The H2 console is available at: http://localhost:8080/api/h2-console

- JDBC URL: `jdbc:h2:mem:userdb`
- Username: `sa`
- Password: `password`

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register a new user
  ```json
  {
    "username": "user1",
    "email": "user1@example.com",
    "password": "password123"
  }
  ```

- `POST /api/auth/login` - Authenticate and get JWT token
  ```json
  {
    "username": "user1",
    "password": "password123"
  }
  ```
  Response:
  ```json
  {
    "token": "eyJhbGciOiJIUzI1NiJ9...",
    "username": "user1"
  }
  ```

### User Management (JWT Protected)

- `GET /api/users` - Get all users
- `GET /api/users/{id}` - Get user by ID
- `PUT /api/users/{id}` - Update user
  ```json
  {
    "username": "updateduser",
    "email": "updated@example.com",
    "password": "newpassword"
  }
  ```
- `DELETE /api/users/{id}` - Delete user
- `GET /api/users/profile` - Get authenticated user's profile

## Default Test User

A default user is created on application startup:
- Username: `admin`
- Password: `password`

## Testing

```bash
# Run tests
mvn test
```

## Security Best Practices

- Passwords are hashed using BCrypt
- JWT tokens are signed with a secure secret
- Input validation for all DTOs
- CORS configuration for API security
- Proper error handling without exposing sensitive information