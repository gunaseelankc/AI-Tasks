# User Management Microservice Documentation

## Overview
This document provides comprehensive information about the User Management microservice built with Spring Boot. The service provides RESTful APIs for user registration, authentication, and management with JWT-based security.

## Architecture
The microservice follows a layered architecture:
- **Controller Layer**: Handles HTTP requests and responses
- **Service Layer**: Contains business logic
- **Repository Layer**: Manages data access
- **Security Layer**: Implements JWT authentication

## Technology Stack
- Java 17
- Spring Boot 3.x
- Spring Data JPA
- Spring Security with JWT
- H2 Database (in-memory)
- JUnit 5 & Mockito for testing

## API Endpoints

### Authentication Endpoints

#### Register a new user
- **URL**: `/api/auth/register`
- **Method**: POST
- **Request Body**:
  ```json
  {
    "username": "testuser",
    "email": "test@example.com",
    "password": "password123"
  }
  ```
- **Response**: HTTP 201 Created
- **cURL Example**:
  ```bash
  curl -X POST http://localhost:8080/api/auth/register \
    -H "Content-Type: application/json" \
    -d '{"username":"testuser","email":"test@example.com","password":"password123"}'
  ```

#### Login
- **URL**: `/api/auth/login`
- **Method**: POST
- **Request Body**:
  ```json
  {
    "username": "testuser",
    "password": "password123"
  }
  ```
- **Response**:
  ```json
  {
    "token": "eyJhbGciOiJIUzI1NiJ9...",
    "username": "testuser"
  }
  ```
- **cURL Example**:
  ```bash
  curl -X POST http://localhost:8080/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{"username":"testuser","password":"password123"}'
  ```

### User Management Endpoints (JWT Protected)

#### Get all users
- **URL**: `/api/users`
- **Method**: GET
- **Headers**: Authorization: Bearer {JWT_TOKEN}
- **Response**: List of users
- **cURL Example**:
  ```bash
  curl -X GET http://localhost:8080/api/users \
    -H "Authorization: Bearer YOUR_JWT_TOKEN"
  ```

#### Get user by ID
- **URL**: `/api/users/{id}`
- **Method**: GET
- **Headers**: Authorization: Bearer {JWT_TOKEN}
- **Response**: User details
- **cURL Example**:
  ```bash
  curl -X GET http://localhost:8080/api/users/USER_ID \
    -H "Authorization: Bearer YOUR_JWT_TOKEN"
  ```

#### Update user
- **URL**: `/api/users/{id}`
- **Method**: PUT
- **Headers**: Authorization: Bearer {JWT_TOKEN}
- **Request Body**:
  ```json
  {
    "username": "updateduser",
    "email": "updated@example.com",
    "password": "newpassword"
  }
  ```
- **Response**: Updated user details
- **cURL Example**:
  ```bash
  curl -X PUT http://localhost:8080/api/users/USER_ID \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer YOUR_JWT_TOKEN" \
    -d '{"username":"updateduser","email":"updated@example.com","password":"newpassword"}'
  ```

#### Delete user
- **URL**: `/api/users/{id}`
- **Method**: DELETE
- **Headers**: Authorization: Bearer {JWT_TOKEN}
- **Response**: HTTP 204 No Content
- **cURL Example**:
  ```bash
  curl -X DELETE http://localhost:8080/api/users/USER_ID \
    -H "Authorization: Bearer YOUR_JWT_TOKEN"
  ```

#### Get authenticated user profile
- **URL**: `/api/users/profile`
- **Method**: GET
- **Headers**: Authorization: Bearer {JWT_TOKEN}
- **Response**: Current user details
- **cURL Example**:
  ```bash
  curl -X GET http://localhost:8080/api/users/profile \
    -H "Authorization: Bearer YOUR_JWT_TOKEN"
  ```

## Database Schema

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  username VARCHAR(255) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Security Implementation

### JWT Authentication Flow
1. Client sends credentials to `/api/auth/login`
2. Server validates credentials and returns JWT token
3. Client includes JWT token in Authorization header for subsequent requests
4. Server validates token and processes the request if valid

### Security Features
- Password hashing with BCryptPasswordEncoder
- JWT token with expiration
- Protected endpoints requiring authentication
- CORS configuration for API security

## Default Test User
A default admin user is created on application startup:
- Username: `admin`
- Password: `password`

## Setup and Running

### Prerequisites
- Java 17 or higher
- Maven

### Running the Application
```bash
mvn spring:boot run
```

The application will start on port 8080 with context path `/api`.

### H2 Database Console
The H2 console is available at: http://localhost:8080/api/h2-console
- JDBC URL: `jdbc:h2:mem:userdb`
- Username: `sa`
- Password: `password`

## Testing
```bash
# Run tests
mvn test
```

## Error Handling
The service implements centralized error handling with appropriate HTTP status codes:
- 400 Bad Request: Validation errors
- 401 Unauthorized: Authentication failures
- 404 Not Found: Resource not found
- 409 Conflict: Resource already exists
- 500 Internal Server Error: Unexpected errors

## Best Practices Implemented
- Layered architecture for separation of concerns
- DTO pattern for data transfer
- Centralized exception handling
- Input validation
- Comprehensive logging
- Secure password storage
- JWT-based authentication