# Gilded Rose starting position in Scala 3 scalatest


## Build the project

``` cmd
sbt compile
```

## Run the Gilded Rose Command-Line program

For e.g. 10 days:

``` cmd
sbt "run 10"
```

## Run all the unit tests

``` cmd
sbt test
```
