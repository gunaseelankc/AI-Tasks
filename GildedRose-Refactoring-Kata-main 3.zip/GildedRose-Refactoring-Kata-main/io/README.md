# Gilded Rose starting position in Io

## Run the unit tests from the Command-Line

```shell
io ./tests/correctness/run.io
```

## Run the TextTest Fixture from Command-Line

```shell
io ./tests/correctness/TexttestFixture.io
```

### Specify Number of Days

For e.g. 10 days:

```shell
io ./tests/correctness/TexttestFixture.io 10
```
