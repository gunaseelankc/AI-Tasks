class Item {
  constructor(name, sellIn, quality){
    this.name = name;
    this.sellIn = sellIn;
    this.quality = quality;
  }
}

class Shop {
  static ITEM_NAMES = {
    AGED_BRIE: 'Aged Brie',
    SULFURAS: 'Sulfuras, Hand of Ragnaros',
    BACKSTAGE_PASSES: 'Backstage passes to a TAFKAL80ETC concert',
    CONJURED: 'Conjured'
  };

  static QUALITY_LIMITS = {
    MIN: 0,
    MAX: 50,
    SULFURAS: 80
  };

  static BACKSTAGE_THRESHOLDS = {
    DOUBLE_INCREASE: 10,
    TRIPLE_INCREASE: 5
  };

  constructor(items=[]){
    this.items = items;
  }

  updateQuality() {
    for (const item of this.items) {
      this.updateSingleItem(item);
    }
    return this.items;
  }

  updateSingleItem(item) {
    if (this.isSulfuras(item)) {
      return; // Sulfuras never changes
    }

    this.updateItemQuality(item);
    this.decreaseSellIn(item);
    this.applyExpiredEffects(item);
  }

  updateItemQuality(item) {
    if (this.isAgedBrie(item)) {
      this.increaseQuality(item);
    } else if (this.isBackstagePasses(item)) {
      this.updateBackstagePassesQuality(item);
    } else if (this.isConjured(item)) {
      this.decreaseQuality(item, 2);
    } else {
      this.decreaseQuality(item);
    }
  }

  updateBackstagePassesQuality(item) {
    this.increaseQuality(item);
    
    if (item.sellIn <= Shop.BACKSTAGE_THRESHOLDS.DOUBLE_INCREASE) {
      this.increaseQuality(item);
    }
    
    if (item.sellIn <= Shop.BACKSTAGE_THRESHOLDS.TRIPLE_INCREASE) {
      this.increaseQuality(item);
    }
  }

  applyExpiredEffects(item) {
    if (item.sellIn >= 0) return;

    if (this.isAgedBrie(item)) {
      this.increaseQuality(item);
    } else if (this.isBackstagePasses(item)) {
      item.quality = Shop.QUALITY_LIMITS.MIN;
    } else if (this.isConjured(item)) {
      this.decreaseQuality(item, 2);
    } else {
      this.decreaseQuality(item);
    }
  }

  increaseQuality(item, amount = 1) {
    item.quality = Math.min(item.quality + amount, Shop.QUALITY_LIMITS.MAX);
  }

  decreaseQuality(item, amount = 1) {
    item.quality = Math.max(item.quality - amount, Shop.QUALITY_LIMITS.MIN);
  }

  decreaseSellIn(item) {
    item.sellIn -= 1;
  }

  isAgedBrie(item) {
    return item.name === Shop.ITEM_NAMES.AGED_BRIE;
  }

  isSulfuras(item) {
    return item.name === Shop.ITEM_NAMES.SULFURAS;
  }

  isBackstagePasses(item) {
    return item.name === Shop.ITEM_NAMES.BACKSTAGE_PASSES;
  }

  isConjured(item) {
    return item.name.includes(Shop.ITEM_NAMES.CONJURED);
  }
}

module.exports = {
  Item,
  Shop
}
