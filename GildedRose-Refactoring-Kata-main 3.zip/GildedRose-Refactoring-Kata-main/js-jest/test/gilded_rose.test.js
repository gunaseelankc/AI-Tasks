const {Shop, Item} = require("../src/gilded_rose");

describe("Gilded Rose", function() {
  
  describe("Normal Items", function() {
    it("should decrease quality and sellIn by 1 for normal items", function() {
      const gildedRose = new Shop([new Item("Normal Item", 5, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(4);
      expect(items[0].quality).toBe(9);
    });

    it("should degrade quality twice as fast after sell date", function() {
      const gildedRose = new Shop([new Item("Normal Item", 0, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(-1);
      expect(items[0].quality).toBe(8); // Degrades by 2
    });

    it("should never have negative quality", function() {
      const gildedRose = new Shop([new Item("Normal Item", 5, 0)]);
      const items = gildedRose.updateQuality();
      expect(items[0].quality).toBe(0);
    });

    it("should never have negative quality after sell date", function() {
      const gildedRose = new Shop([new Item("Normal Item", 0, 1)]);
      const items = gildedRose.updateQuality();
      expect(items[0].quality).toBe(0);
    });
  });

  describe("Aged Brie", function() {
    it("should increase quality as it ages", function() {
      const gildedRose = new Shop([new Item("Aged Brie", 5, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(4);
      expect(items[0].quality).toBe(11);
    });

    it("should increase quality twice as fast after sell date", function() {
      const gildedRose = new Shop([new Item("Aged Brie", 0, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(-1);
      expect(items[0].quality).toBe(12);
    });

    it("should never exceed quality of 50", function() {
      const gildedRose = new Shop([new Item("Aged Brie", 5, 50)]);
      const items = gildedRose.updateQuality();
      expect(items[0].quality).toBe(50);
    });

    it("should not exceed quality of 50 after sell date", function() {
      const gildedRose = new Shop([new Item("Aged Brie", 0, 49)]);
      const items = gildedRose.updateQuality();
      expect(items[0].quality).toBe(50);
    });
  });

  describe("Sulfuras, Hand of Ragnaros", function() {
    it("should never change quality or sellIn", function() {
      const gildedRose = new Shop([new Item("Sulfuras, Hand of Ragnaros", 5, 80)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(5);
      expect(items[0].quality).toBe(80);
    });

    it("should never change even after sell date", function() {
      const gildedRose = new Shop([new Item("Sulfuras, Hand of Ragnaros", 0, 80)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(0);
      expect(items[0].quality).toBe(80);
    });
  });

  describe("Backstage passes to a TAFKAL80ETC concert", function() {
    it("should increase quality by 1 when more than 10 days", function() {
      const gildedRose = new Shop([new Item("Backstage passes to a TAFKAL80ETC concert", 15, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(14);
      expect(items[0].quality).toBe(11);
    });

    it("should increase quality by 2 when 10 days or less", function() {
      const gildedRose = new Shop([new Item("Backstage passes to a TAFKAL80ETC concert", 10, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(9);
      expect(items[0].quality).toBe(12);
    });

    it("should increase quality by 3 when 5 days or less", function() {
      const gildedRose = new Shop([new Item("Backstage passes to a TAFKAL80ETC concert", 5, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(4);
      expect(items[0].quality).toBe(13);
    });

    it("should drop quality to 0 after concert", function() {
      const gildedRose = new Shop([new Item("Backstage passes to a TAFKAL80ETC concert", 0, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(-1);
      expect(items[0].quality).toBe(0);
    });

    it("should never exceed quality of 50", function() {
      const gildedRose = new Shop([new Item("Backstage passes to a TAFKAL80ETC concert", 5, 49)]);
      const items = gildedRose.updateQuality();
      expect(items[0].quality).toBe(50);
    });
  });

  describe("Conjured Items", function() {
    it("should degrade quality twice as fast as normal items", function() {
      const gildedRose = new Shop([new Item("Conjured Mana Cake", 5, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(4);
      expect(items[0].quality).toBe(8);
    });

    it("should degrade quality four times as fast after sell date", function() {
      const gildedRose = new Shop([new Item("Conjured Mana Cake", 0, 10)]);
      const items = gildedRose.updateQuality();
      expect(items[0].sellIn).toBe(-1);
      expect(items[0].quality).toBe(6);
    });

    it("should never have negative quality", function() {
      const gildedRose = new Shop([new Item("Conjured Mana Cake", 5, 1)]);
      const items = gildedRose.updateQuality();
      expect(items[0].quality).toBe(0);
    });

    it("should never have negative quality after sell date", function() {
      const gildedRose = new Shop([new Item("Conjured Mana Cake", 0, 3)]);
      const items = gildedRose.updateQuality();
      expect(items[0].quality).toBe(0);
    });
  });

  describe("Multiple Items", function() {
    it("should handle multiple different items correctly", function() {
      const items = [
        new Item("Normal Item", 5, 10),
        new Item("Aged Brie", 3, 5),
        new Item("Sulfuras, Hand of Ragnaros", 0, 80),
        new Item("Backstage passes to a TAFKAL80ETC concert", 8, 15),
        new Item("Conjured Mana Cake", 4, 8)
      ];
      const gildedRose = new Shop(items);
      const updatedItems = gildedRose.updateQuality();
      
      expect(updatedItems[0].sellIn).toBe(4);
      expect(updatedItems[0].quality).toBe(9);
      
      expect(updatedItems[1].sellIn).toBe(2);
      expect(updatedItems[1].quality).toBe(6);
      
      expect(updatedItems[2].sellIn).toBe(0);
      expect(updatedItems[2].quality).toBe(80);
      
      expect(updatedItems[3].sellIn).toBe(7);
      expect(updatedItems[3].quality).toBe(17);
      
      expect(updatedItems[4].sellIn).toBe(3);
      expect(updatedItems[4].quality).toBe(6);
    });
  });
});
