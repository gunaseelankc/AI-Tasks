cobc --free --std=mf -O *.cbl
