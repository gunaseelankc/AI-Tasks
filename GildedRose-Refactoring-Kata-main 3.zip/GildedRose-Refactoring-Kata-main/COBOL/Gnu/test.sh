./build.sh
./run.sh
